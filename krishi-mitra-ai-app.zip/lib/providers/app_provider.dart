import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'translations.dart';

class AppProvider extends ChangeNotifier {
  String _language = 'en';
  bool _isOnline = true;
  late SharedPreferences _prefs;

  AppProvider() {
    _initPrefs();
  }

  String get language => _language;
  bool get isOnline => _isOnline;

  Future<void> _initPrefs() async {
    _prefs = await SharedPreferences.getInstance();
    _language = _prefs.getString('language') ?? 'en';
    notifyListeners();
  }

  Future<void> setLanguage(String lang) async {
    _language = lang;
    await _prefs.setString('language', lang);
    notifyListeners();
  }

  void setOnlineStatus(bool status) {
    _isOnline = status;
    notifyListeners();
  }

  /// Get translated string for key in current language
  String t(String key) {
    return Translations.translate(_language, key);
  }

  /// Get translated string in specific language
  String tInLanguage(String key, String language) {
    return Translations.translate(language, key);
  }

  /// Get list of supported language codes
  List<String> getSupportedLanguages() {
    return Translations.getSupportedLanguages();
  }
}

  String get language => _language;
  bool get isOnline => _isOnline;

  Future<void> _initPrefs() async {
    _prefs = await SharedPreferences.getInstance();
    _language = _prefs.getString('language') ?? 'en';
    notifyListeners();
  }

  Future<void> setLanguage(String lang) async {
    _language = lang;
    await _prefs.setString('language', lang);
    notifyListeners();
  }

  void setOnlineStatus(bool status) {
    _isOnline = status;
    notifyListeners();
  }

  String t(String key) {
    final translations = {
      'en': {
        'app_title': 'KrishiMitra AI',
        'splash_title': 'Welcome to KrishiMitra',
        'splash_subtitle': 'Your AI Farming Assistant',
        'start_farming': 'Start Farming',
        'farmer_name': 'Farmer Name',
        'village': 'Village/District',
        'land_size': 'Land Size (acres)',
        'soil_type': 'Soil Type',
        'water_source': 'Water Source',
        'register': 'Register',
        'dashboard': 'Dashboard',
        'crop_recommendation': 'Crop Recommendation',
        'water_advisory': 'Water Advisory',
        'disease_detection': 'Disease Detection',
        'weather_alerts': 'Weather Alerts',
        'expert_connect': 'Connect with Experts',
        'ai_chat': 'AI Assistant',
        'offline_mode': 'Offline Mode',
      },
      'hi': {
        'app_title': 'कृषि मित्र एआई',
        'splash_title': 'कृषि मित्र में स्वागत है',
        'splash_subtitle': 'आपका एआई कृषि सहायक',
        'start_farming': 'खेती शुरू करें',
        'farmer_name': 'किसान का नाम',
        'village': 'गांव/जिला',
        'land_size': 'भूमि का आकार (एकड़)',
        'soil_type': 'मिट्टी का प्रकार',
        'water_source': 'जल स्रोत',
        'register': 'पंजीकृत करें',
        'dashboard': 'डैशबोर्ड',
        'crop_recommendation': 'फसल की सिफारिश',
        'water_advisory': 'जल सलाह',
        'disease_detection': 'रोग पहचान',
        'weather_alerts': 'मौसम सतर्कता',
        'expert_connect': 'विशेषज्ञों से जुड़ें',
        'ai_chat': 'एआई सहायक',
        'offline_mode': 'ऑफलाइन मोड',
      },
      'mr': {
        'app_title': 'कृषी मित्र एआই',
        'splash_title': 'कृषी मित्रात स्वागत आहे',
        'splash_subtitle': 'आपला एआই शेती सहायक',
        'start_farming': 'शेती सुरू करा',
        'farmer_name': 'शेतकरीचे नाव',
        'village': 'गाव/जिल्हा',
        'land_size': 'जमिनीचा आकार (एकर)',
        'soil_type': 'मातीचा प्रकार',
        'water_source': 'जलस्रोत',
        'register': 'नोंदणी करा',
        'dashboard': 'डॅशबोर्ड',
        'crop_recommendation': 'पिकाची शिफारस',
        'water_advisory': 'पाण्याचा सल्ला',
        'disease_detection': 'रोगाचे निदान',
        'weather_alerts': 'हवामान सतर्कता',
        'expert_connect': 'तज्ञांशी जुळा',
        'ai_chat': 'एआই सहायक',
        'offline_mode': 'ऑफलाइन मोड',
      },
    };

    return translations[_language]?[key] ?? key;
  }
}
