import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class FarmerData {
  final String name;
  final String village;
  final double landSize;
  final String soilType;
  final String waterSource;
  final double latitude;
  final double longitude;

  FarmerData({
    required this.name,
    required this.village,
    required this.landSize,
    required this.soilType,
    required this.waterSource,
    required this.latitude,
    required this.longitude,
  });

  Map<String, dynamic> toJson() => {
    'name': name,
    'village': village,
    'landSize': landSize,
    'soilType': soilType,
    'waterSource': waterSource,
    'latitude': latitude,
    'longitude': longitude,
  };

  factory FarmerData.fromJson(Map<String, dynamic> json) => FarmerData(
    name: json['name'] ?? '',
    village: json['village'] ?? '',
    landSize: json['landSize'] ?? 0.0,
    soilType: json['soilType'] ?? '',
    waterSource: json['waterSource'] ?? '',
    latitude: json['latitude'] ?? 0.0,
    longitude: json['longitude'] ?? 0.0,
  );
}

class FarmerProvider extends ChangeNotifier {
  FarmerData? _farmer;
  bool _isRegistered = false;
  late SharedPreferences _prefs;

  FarmerProvider() {
    _initPrefs();
  }

  FarmerData? get farmer => _farmer;
  bool get isRegistered => _isRegistered;

  Future<void> _initPrefs() async {
    _prefs = await SharedPreferences.getInstance();
    final farmerJson = _prefs.getString('farmer_data');
    if (farmerJson != null) {
      _farmer = FarmerData.fromJson(jsonDecode(farmerJson));
      _isRegistered = true;
      notifyListeners();
    }
  }

  Future<void> registerFarmer(FarmerData farmer) async {
    _farmer = farmer;
    _isRegistered = true;
    await _prefs.setString('farmer_data', jsonEncode(farmer.toJson()));
    notifyListeners();
  }

  Future<void> clearFarmer() async {
    _farmer = null;
    _isRegistered = false;
    await _prefs.remove('farmer_data');
    notifyListeners();
  }
}
