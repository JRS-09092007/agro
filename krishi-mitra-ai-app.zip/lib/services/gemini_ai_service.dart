import 'package:google_generative_ai/google_generative_ai.dart';

class GeminiAIService {
  late GenerativeModel _model;
  final String apiKey;
  
  GeminiAIService({required this.apiKey}) {
    _model = GenerativeModel(
      model: 'gemini-pro',
      apiKey: apiKey,
    );
  }

  /// Generate AI response for farming questions
  Future<String> generateFarmingAdvice({
    required String question,
    required String language,
    required Map<String, dynamic> farmerContext,
  }) async {
    try {
      final systemPrompt = _buildSystemPrompt(language, farmerContext);
      
      final content = [
        Content.text(systemPrompt),
        Content.text(question),
      ];

      final response = await _model.generateContent(content);
      return response.text ?? 'Unable to generate response';
    } catch (e) {
      print('[v0] Gemini Error: $e');
      return _getFallbackResponse(language, question);
    }
  }

  /// Stream AI response for real-time chat
  Stream<String> streamFarmingAdvice({
    required String question,
    required String language,
    required Map<String, dynamic> farmerContext,
  }) {
    try {
      final systemPrompt = _buildSystemPrompt(language, farmerContext);
      
      final content = [
        Content.text(systemPrompt),
        Content.text(question),
      ];

      return _model.generateContentStream(content).map((response) {
        return response.text ?? '';
      });
    } catch (e) {
      print('[v0] Gemini Stream Error: $e');
      return Stream.value(_getFallbackResponse(language, question));
    }
  }

  /// Build context-aware system prompt
  String _buildSystemPrompt(String language, Map<String, dynamic> context) {
    final farmerName = context['farmerName'] ?? 'Farmer';
    final location = context['location'] ?? 'region';
    final soilType = context['soilType'] ?? 'soil';
    final landSize = context['landSize'] ?? 'acres';
    final waterSource = context['waterSource'] ?? 'irrigation';

    final languageInstructions = {
      'en': 'Respond in English',
      'hi': 'हिंदी में उत्तर दें',
      'mr': 'मराठीत उत्तर द्या',
      'te': 'తెలుగులో సమాధానం ఇవ్వండి',
      'ta': 'தமிழில் பதிலளிக்கவும்',
      'kn': 'ಕನ್ನಡದಲ್ಲಿ ಉತ್ತರ ಕೊಡಿ',
    }[language] ?? 'Respond in English';

    return '''
You are KrishiMitra, an expert agricultural AI assistant specifically designed for Indian farmers.

Farmer Context:
- Name: $farmerName
- Location: $location
- Soil Type: $soilType
- Land Size: $landSize acres
- Water Source: $waterSource

Instructions:
1. $languageInstructions
2. Provide practical, actionable farming advice
3. Use local agricultural terminology
4. Consider Indian weather patterns and crop seasons
5. Include water management tips
6. Mention government subsidies or schemes when relevant
7. Be encouraging and supportive
8. Keep responses concise but informative

Now, answer the following question:
''';
  }

  /// Get fallback response when API fails
  String _getFallbackResponse(String language, String question) {
    final fallbacks = {
      'en': 'I\'m having trouble processing your request. Please try again in a moment.',
      'hi': 'मुझे आपके अनुरोध को संसाधित करने में परेशानी हो रही है। कृपया थोड़ी देर बाद पुनः प्रयास करें।',
      'mr': 'मला तुमच्या विनंतीवर कार्य करण्यात अडचण येत आहे. कृपया थोड्या वेळाने पुन्हा प्रयत्न करा.',
      'te': 'మీ అభ్యర్థనను ప్రక్రియ చేయడంలో నాకు సమస్య ఉంది. దయచేసి కొద్దిసేపట్లో మళ్ళీ ప్రయత్నించండి.',
      'ta': 'உங்கள் கோரிக்கையை செயல்படுத்த எனக்கு சிக்கல் ஏற்பட்டுள்ளது. தயவுசெய்து சிறிது நேரத்தில் மீண்டும் முயற்சிக்கவும்.',
      'kn': 'ನಿಮ್ಮ ವಿನಂತಿಯನ್ನು ಪ್ರಕ್ರಿಯೆ ಮಾಡುವಲ್ಲಿ ನನಗೆ ಸಮಸ್ಯೆ ಉಂಟಾಗಿದೆ. ದಯವಿಟ್ಟು ಸ್ವಲ್ಪ ಸಮಯದ ನಂತರ ಮತ್ತೆ ಪ್ರಯತ್ನಿಸಿ.',
    };
    return fallbacks[language] ?? fallbacks['en']!;
  }
}
