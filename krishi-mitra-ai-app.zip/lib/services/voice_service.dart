import 'package:speech_to_text/speech_to_text.dart' as stt;
import 'package:flutter_tts/flutter_tts.dart';

class VoiceService {
  final stt.SpeechToText _speechToText = stt.SpeechToText();
  final FlutterTts _tts = FlutterTts();
  
  final Map<String, String> languageMap = {
    'en': 'en-US',
    'hi': 'hi-IN',
    'mr': 'mr-IN',
    'te': 'te-IN',
    'ta': 'ta-IN',
    'kn': 'kn-IN',
  };

  VoiceService() {
    _initializeServices();
  }

  Future<void> _initializeServices() async {
    try {
      // Initialize speech to text
      final available = await _speechToText.initialize(
        onError: (error) => print('[v0] Speech Error: $error'),
        onStatus: (status) => print('[v0] Speech Status: $status'),
      );
      
      if (!available) {
        print('[v0] Speech to text not available');
      }

      // Initialize text to speech
      await _tts.setLanguage('en-US');
      await _tts.setPitch(1.0);
      await _tts.setSpeechRate(0.5);
    } catch (e) {
      print('[v0] Voice Service Init Error: $e');
    }
  }

  /// Start listening for voice input
  Future<String?> startListening(String language) async {
    try {
      if (!_speechToText.isAvailable) {
        print('[v0] Speech recognition not available');
        return null;
      }

      final localeId = languageMap[language] ?? 'en-US';
      
      _speechToText.listen(
        onResult: (result) {
          print('[v0] Recognized: ${result.recognizedWords}');
        },
        localeId: localeId,
      );

      // Wait for speech recognition to complete
      while (_speechToText.isListening) {
        await Future.delayed(const Duration(milliseconds: 100));
      }

      return _speechToText.lastRecognizedWords;
    } catch (e) {
      print('[v0] Listen Error: $e');
      return null;
    }
  }

  /// Stop listening
  Future<void> stopListening() async {
    try {
      if (_speechToText.isListening) {
        await _speechToText.stop();
      }
    } catch (e) {
      print('[v0] Stop Listen Error: $e');
    }
  }

  /// Speak text in specified language
  Future<void> speak(String text, String language) async {
    try {
      final localeId = languageMap[language] ?? 'en-US';
      
      await _tts.setLanguage(localeId);
      await _tts.speak(text);
    } catch (e) {
      print('[v0] Speak Error: $e');
    }
  }

  /// Stop speaking
  Future<void> stopSpeaking() async {
    try {
      await _tts.stop();
    } catch (e) {
      print('[v0] Stop Speak Error: $e');
    }
  }

  /// Check if currently listening
  bool isListening() => _speechToText.isListening;

  /// Get available languages
  List<String> getAvailableLanguages() => languageMap.keys.toList();
}
