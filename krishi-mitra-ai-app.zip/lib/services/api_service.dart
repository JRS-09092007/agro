import 'package:dio/dio.dart';
import 'translations.dart';

class WeatherData {
  final String temp;
  final String humidity;
  final String rainfall;
  final String windSpeed;
  final String condition;

  WeatherData({
    required this.temp,
    required this.humidity,
    required this.rainfall,
    required this.windSpeed,
    required this.condition,
  });
}

class CropRecommendation {
  final String cropName;
  final String season;
  final String waterNeeded;
  final String expectedYield;
  final String marketPrice;

  CropRecommendation({
    required this.cropName,
    required this.season,
    required this.waterNeeded,
    required this.expectedYield,
    required this.marketPrice,
  });
}

class AirQualityData {
  final String pm25;
  final String pm10;
  final String o3;
  final String no2;
  final String aqi;

  AirQualityData({
    required this.pm25,
    required this.pm10,
    required this.o3,
    required this.no2,
    required this.aqi,
  });
}

class ApiService {
  final Dio _dio = Dio();
  
  // IMD Weather API - Free public data
  Future<WeatherData> getWeatherData(double latitude, double longitude) async {
    try {
      // Using Open-Meteo API (free alternative) for weather data
      final response = await _dio.get(
        'https://api.open-meteo.com/v1/forecast',
        queryParameters: {
          'latitude': latitude,
          'longitude': longitude,
          'current': 'temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m,precipitation',
          'temperature_unit': 'celsius',
          'wind_speed_unit': 'kmh',
        },
      );

      if (response.statusCode == 200) {
        final current = response.data['current'];
        return WeatherData(
          temp: '${current['temperature_2m'].toStringAsFixed(1)}°C',
          humidity: '${current['relative_humidity_2m']}%',
          rainfall: '${current['precipitation']}mm',
          windSpeed: '${current['wind_speed_10m']} km/h',
          condition: _getWeatherCondition(current['weather_code']),
        );
      }
      return _getDefaultWeather();
    } catch (e) {
      return _getDefaultWeather();
    }
  }

  // data.gov.in Agriculture Department - Crop recommendations
  Future<List<CropRecommendation>> getCropRecommendations(
    String soilType,
    String season,
    String waterAvailability,
  ) async {
    try {
      // Mock data based on Indian agriculture datasets
      final crops = _getCropsByConditions(soilType, season, waterAvailability);
      return crops;
    } catch (e) {
      return _getDefaultCrops();
    }
  }

  // CPCB Air Quality Data - Air quality monitoring
  Future<AirQualityData> getAirQuality(double latitude, double longitude) async {
    try {
      // Using Open-Meteo AQI API (free) which is based on Copernicus/CPCB standards
      final response = await _dio.get(
        'https://air-quality-api.open-meteo.com/v1/air-quality',
        queryParameters: {
          'latitude': latitude,
          'longitude': longitude,
          'current': 'pm10,pm2_5,ozone,nitrogen_dioxide,us_air_quality_index',
        },
      );

      if (response.statusCode == 200) {
        final current = response.data['current'];
        return AirQualityData(
          pm25: '${current['pm2_5']?.toStringAsFixed(1) ?? 'N/A'} μg/m³',
          pm10: '${current['pm10']?.toStringAsFixed(1) ?? 'N/A'} μg/m³',
          o3: '${current['ozone']?.toStringAsFixed(1) ?? 'N/A'} ppb',
          no2: '${current['nitrogen_dioxide']?.toStringAsFixed(1) ?? 'N/A'} ppb',
          aqi: '${current['us_air_quality_index'] ?? 'N/A'}',
        );
      }
      return _getDefaultAirQuality();
    } catch (e) {
      return _getDefaultAirQuality();
    }
  }

  // Census/NFHS Data Integration - Demographics for targeted interventions
  Future<Map<String, dynamic>> getDemographicData(String district) async {
    try {
      // This would connect to data.gov.in Census/NFHS APIs
      // For now, returning structured format that matches NFHS data
      return {
        'district': district,
        'ruralPopulation': 'Data from Census 2021',
        'literacyRate': 'Data from Census 2021',
        'avgFarmSize': 'Data from Census Agriculture',
        'primaryCrop': 'Based on regional data',
      };
    } catch (e) {
      return {};
    }
  }

  // Helper methods
  String _getWeatherCondition(int code) {
    // WMO Weather interpretation codes
    if (code == 0) return 'Clear';
    if (code == 1 || code == 2) return 'Partly Cloudy';
    if (code == 3) return 'Overcast';
    if (code == 45 || code == 48) return 'Foggy';
    if (code == 51 || code == 53 || code == 55) return 'Drizzle';
    if (code == 61 || code == 63 || code == 65) return 'Rain';
    if (code == 71 || code == 73 || code == 75) return 'Snow';
    if (code == 80 || code == 81 || code == 82) return 'Showers';
    if (code == 85 || code == 86) return 'Snow Showers';
    if (code == 95 || code == 96 || code == 99) return 'Thunderstorm';
    return 'Unknown';
  }

  WeatherData _getDefaultWeather() {
    return WeatherData(
      temp: '28°C',
      humidity: '70%',
      rainfall: '0mm',
      windSpeed: '8 km/h',
      condition: 'Partly Cloudy',
    );
  }

  List<CropRecommendation> _getCropsByConditions(
    String soilType,
    String season,
    String waterAvailability,
  ) {
    // Based on Indian agricultural science datasets
    final recommendations = <CropRecommendation>[
      if (soilType == 'loamy' && season == 'kharif')
        CropRecommendation(
          cropName: 'Rice',
          season: 'Monsoon',
          waterNeeded: '120-150 cm',
          expectedYield: '40-50 q/ha',
          marketPrice: '₹2,100-2,300',
        ),
      if (soilType == 'black' && season == 'rabi')
        CropRecommendation(
          cropName: 'Cotton',
          season: 'Winter',
          waterNeeded: '60-80 cm',
          expectedYield: '15-20 q/ha',
          marketPrice: '₹5,500-6,000',
        ),
      CropRecommendation(
        cropName: 'Wheat',
        season: 'Winter',
        waterNeeded: '40-50 cm',
        expectedYield: '40-50 q/ha',
        marketPrice: '₹2,200-2,500',
      ),
      CropRecommendation(
        cropName: 'Pulses',
        season: 'Rabi',
        waterNeeded: '30-40 cm',
        expectedYield: '15-20 q/ha',
        marketPrice: '₹4,000-4,500',
      ),
    ];

    return recommendations.isNotEmpty ? recommendations : _getDefaultCrops();
  }

  List<CropRecommendation> _getDefaultCrops() {
    return [
      CropRecommendation(
        cropName: 'Rice',
        season: 'Monsoon',
        waterNeeded: '120-150 cm',
        expectedYield: '40-50 q/ha',
        marketPrice: '₹2,100-2,300',
      ),
      CropRecommendation(
        cropName: 'Wheat',
        season: 'Winter',
        waterNeeded: '40-50 cm',
        expectedYield: '40-50 q/ha',
        marketPrice: '₹2,200-2,500',
      ),
    ];
  }

  AirQualityData _getDefaultAirQuality() {
    return AirQualityData(
      pm25: '45.2 μg/m³',
      pm10: '78.5 μg/m³',
      o3: '35.0 ppb',
      no2: '28.5 ppb',
      aqi: '125',
    );
  }

  /// Generate AI response in local language
  String generateAIResponse(
    String language,
    String questionType,
    Map<String, dynamic> context,
  ) {
    final cropName = context['crop'] ?? 'recommended crop';
    final soilType = context['soil'] ?? 'your soil';
    final season = context['season'] ?? 'current season';
    final waterNeeded = context['water'] ?? '60-80 cm';

    final aiResponses = {
      'en': {
        'greeting': 'Namaste! Welcome to KrishiMitra AI. How can I assist you with your farming?',
        'crop_recommendation': 'Based on your soil type ($soilType) and $season season, I recommend growing $cropName. It requires approximately $waterNeeded of water and is well-suited to your region.',
        'water_advice': 'Your farm needs irrigation in the next 2-3 days. Current soil moisture is moderate. I recommend drip irrigation for water conservation.',
        'weather_info': 'The forecast shows partly cloudy conditions with 30% chance of rain. Temperatures will range from 28-35°C.',
        'disease_tip': 'Keep monitoring your crops daily. Early detection of diseases helps prevent spread.',
        'pest_management': 'For pest management, consider using integrated pest management (IPM) techniques.',
      },
      'hi': {
        'greeting': 'नमस्ते! कृषि मित्र में आपका स्वागत है। मैं आपकी खेती में कैसे मदद कर सकता हूं?',
        'crop_recommendation': 'आपकी मिट्टी के प्रकार ($soilType) और $season ऋतु के आधार पर, मैं $cropName उगाने की सिफारिश करता हूं। इसके लिए लगभग $waterNeeded पानी की आवश्यकता है।',
        'water_advice': 'आपकी खेत को अगले 2-3 दिनों में सिंचाई की आवश्यकता है। वर्तमान मिट्टी की नमी मध्यम है। मैं जल संरक्षण के लिए ड्रिप सिंचाई की सिफारिश करता हूं।',
        'weather_info': 'पूर्वानुमान आंशिक बादल वाली स्थिति दिखाता है जिसमें 30% वर्षा की संभावना है। तापमान 28-35°C के बीच रहेगा।',
        'disease_tip': 'अपनी फसलों की दैनिक निगरानी करते रहें। रोगों का जल्दी पता चलने से फैलाव रोका जा सकता है।',
        'pest_management': 'कीट प्रबंधन के लिए, एकीकृत कीट प्रबंधन (आईपीएम) तकनीकों का उपयोग करने पर विचार करें।',
      },
      'mr': {
        'greeting': 'नमस्कार! कृषी मित्रात स्वागत आहे. मैं आपल्या शेतीमध्ये कसे मदत करू शकतो?',
        'crop_recommendation': 'आपल्या माती प्रकार ($soilType) आणि $season ऋतु आधारावर, मी $cropName वाढवण्याची शिफारस करतो. याला अंदाजे $waterNeeded पाणी आवश्यक आहे.',
        'water_advice': 'आपल्या खेतास पुढील 2-3 दिवसांमध्ये सिंचन आवश्यक आहे. वर्तमान माती आर्द्रता मध्यम आहे. मी जल संरक्षणासाठी ड्रिप सिंचन सुझाव देतो.',
        'weather_info': 'अंदाज आंशिक ढगाळ परिस्थिती दर्शवितो जेथे 30% पाऊस असण्याची शक्यता आहे. तापमान 28-35°C दरम्यान असेल.',
        'disease_tip': 'आपल्या पिकांचे दैनिक निरीक्षण करत रहा. रोगांचे लवकर शोधण्यामुळे प्रसार रोखता येतो.',
        'pest_management': 'कीटक व्यवस्थापनासाठी, एकीकृत कीटक व्यवस्थापन (IPM) तंत्र वापरण्याचा विचार करा.',
      },
      'te': {
        'greeting': 'నమస్కారం! కృషిమిత్రకు స్వాగతం. నేను మీ వ్యవసాయంలో ఎలా సహాయం చేయవచ్చు?',
        'crop_recommendation': 'మీ మట్టి రకం ($soilType) మరియు $season కాలం ఆధారంగా, నేను $cropName పండించాలని సిఫారసు చేస్తున్నాను.',
        'water_advice': 'మీ పొలకు రాబోయే 2-3 రోజుల్లో నీటిపారవchunocum అవసరం. ప్రస్తుత మట్టి తేమ మధ్యమ స్థాయిలో ఉంది.',
        'weather_info': 'వాతావరణ సూచన 30% వర్షపాతం సంభావ్యతతో పాక్షిక మేఘావృత పరిస్థితులను చూపుతుంది.',
        'disease_tip': 'మీ పంటలను రోజూ పర్యవేక్షించండి. వ్యాధుల యొక్క ముందుగా గుర్తించడం ఎలాంటి ఆపరేషన్‌కు సహాయం చేస్తుంది.',
        'pest_management': 'తెగుళ్ల నిర్వహణ కోసం, సమన్వయ సాధన పీడక నిర్వహణ (IPM) పద్ధతులను ఉపయోగించమని సిఫారసు చేస్తున్నాను.',
      },
      'ta': {
        'greeting': 'வணக்கம்! கிரிஷிமித்திரைக்கு வரவேற்கிறோம். உங்கள் விவசாயத்தில் நான் எவ்வாறு உதவி செய்யலாம்?',
        'crop_recommendation': 'உங்கள் மண் வகை ($soilType) மற்றும் $season காலம் ஆதாரமாக, நான் $cropName பயிரிடுமாறு பரிந்துரைக்கிறேன்.',
        'water_advice': 'உங்கள் பொலிக்கு வரும் 2-3 நாட்களில் நீர்ப்பாசனம் தேவை. தற்போதைய மண் ஈரப்பதம் மধ்यम நிலையில் உள்ளது.',
        'weather_info': 'வானிலை முன்னறிவிப்பு 30% மழையாக வரக்கூடிய பகுதியளவு மேக நிலையை காட்டுகிறது.',
        'disease_tip': 'உங்கள் பயிர்களை தினமும் கண்காணிக்கவும். நோய்கள் முன்னரே கண்டறிதல் பரவலை தடுக்க உதவுகிறது.',
        'pest_management': 'பூச்சி நிர்வாகத்திற்கு, ஒருங்கிணைந்த பூச்சி நிர்வாகம் (IPM) நுட்பங்களைப் பயன்படுத்தமாறு சிபாரிசு செய்கிறேன்.',
      },
      'kn': {
        'greeting': 'ನಮಸ್ಕಾರ! ಕೃಷಿಮಿತ್ರಕ್ಕೆ ಸ್ವಾಗತ. ನಾನು ನಿಮ್ಮ ಕೃಷಿಗಾಗಿ ಹೇಗೆ ಸಹಾಯ ಮಾಡಬಹುದು?',
        'crop_recommendation': 'ನಿಮ್ಮ ಮಣ್ಣಿನ ವಿಧ ($soilType) ಮತ್ತು $season ಅವಧಿ ಆಧಾರದ ಮೇಲೆ, ನಾನು $cropName ಬೆಳೆಯುವಂತೆ ಶಿಫಾರಸು ಮಾಡುತ್ತೇನೆ.',
        'water_advice': 'ನಿಮ್ಮ ಜೇತ್ರಕ್ಕೆ ಮುಂದಿನ 2-3 ದಿನಗಳಲ್ಲಿ ನೀರಾವರ ಅಗತ್ಯವಿದೆ. ಪ್ರಸ್ತುತ ಮಣ್ಣಿನ ತೇವಾಂಶ ಮಧ್ಯಮ ಹಂತದಲ್ಲಿದೆ.',
        'weather_info': 'ವಾತಾವರಣ ಪೂರ್ವಸೂಚನೆ 30% ವರ್ಷಾಪಾತ ಸಾಧ್ಯತೆಯೊಂದಿಗೆ ಭಾಗಶಃ ಮೇಘಲೋಪ ಪರಿಸ್ಥಿತಿಯನ್ನು ತೋರಿಸುತ್ತದೆ.',
        'disease_tip': 'ನಿಮ್ಮ ಸಸ್ಯಗಳನ್ನು ದಿನದಿ ಧ್ಯಾನ ಸೆಳೆಯಿರಿ. ರೋಗಗಳನ್ನು ಮುಂಚೆ ಸನಿಹ ಮಾಡಿದರೆ ಪ್ರಸರ ತಡೆಯುವಲ್ಲಿ ಸಹಾಯ ಮಾಡುತ್ತದೆ.',
        'pest_management': 'ಕೀಟ ನಿರ್ವಹಣೆಗಾಗಿ, ಸಮಗ್ರ ಕೀಟ ನಿರ್ವಹಣೆ (IPM) ತಂತ್ರಗಳನ್ನು ಬಳಸಬೇಕೆಂದು ಶಿಫಾರಸು ಮಾಡುತ್ತೇನೆ.',
      },
    };

    final responses = aiResponses[language] ?? aiResponses['en'] ?? {};
    return responses[questionType] ?? 'How can I assist you with your farming?';
  }
}
