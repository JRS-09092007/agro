"use client"

import React, { createContext, useContext, useState } from "react"

export type Language = "en" | "hi" | "mr" | "te" | "ta" | "kn"
export type Screen =
  | "splash"
  | "registration"
  | "dashboard"
  | "chat"
  | "crop"
  | "water"
  | "disease"
  | "weather"
  | "offline"
  | "expert"

export interface FarmerProfile {
  name: string
  phone: string
  village: string
  district: string
  state: string
  landSize: string
  soilType: string
  waterAvailability: string
  language: Language
}

interface AppContextType {
  screen: Screen
  setScreen: (s: Screen) => void
  language: Language
  setLanguage: (l: Language) => void
  farmer: FarmerProfile
  setFarmer: (f: FarmerProfile) => void
  isOnline: boolean
  t: (key: string) => string
}

const translations: Record<Language, Record<string, string>> = {
  en: {
    appName: "KrishiMitra AI",
    tagline: "Your AI farming companion in your own language",
    startFarming: "Start Farming",
    selectLanguage: "Select Language",
    registration: "Farmer Registration",
    name: "Full Name",
    phone: "Phone Number",
    village: "Village",
    district: "District",
    state: "State",
    landSize: "Land Size (acres)",
    soilType: "Soil Type",
    waterAvailability: "Water Availability",
    preferredLanguage: "Preferred Language",
    register: "Register",
    dashboard: "Dashboard",
    goodMorning: "Good Morning",
    weatherToday: "Weather Today",
    cropRecommendation: "Crop Recommendation",
    waterAdvisory: "Water Advisory",
    diseaseScanner: "Disease Scanner",
    aiAssistant: "AI Assistant",
    onlineMode: "Online Mode Active",
    offlineMode: "Offline Mode Active",
    offlineDesc: "Basic farming advice available",
    chatTitle: "AI Farm Assistant",
    typeMessage: "Type your question...",
    voiceInput: "Voice Input",
    cropTitle: "Crop Recommendation",
    cropSubtitle: "Get AI-powered crop advice",
    season: "Season",
    location: "Location",
    getRecommendation: "Get Recommendation",
    waterTitle: "Water Advisory",
    soilMoisture: "Soil Moisture",
    forecast: "Weather Forecast",
    irrigationRec: "Irrigation Recommendation",
    diseaseTitle: "Crop Disease Detection",
    uploadImage: "Upload Crop Image",
    takePhoto: "Take Photo",
    analyzeImage: "Analyze Image",
    weatherTitle: "Weather Alerts",
    offlineTitle: "Offline Mode",
    syncNow: "Sync when internet returns",
    expertTitle: "Connect with Expert",
    contactCenter: "Contact Rythu Seva Kendra",
    back: "Back",
    submit: "Submit",
    poweredBy: "Powered by Gemini AI",
    recommended: "Recommended Crop",
    confidence: "Confidence",
    treatment: "Treatment",
    diseaseDetected: "Disease Detected",
  },
  hi: {
    appName: "कृषि मित्र AI",
    tagline: "आपकी भाषा में आपका AI कृषि साथी",
    startFarming: "खेती शुरू करें",
    selectLanguage: "भाषा चुनें",
    registration: "किसान पंजीकरण",
    name: "पूरा नाम",
    phone: "फोन नंबर",
    village: "गांव",
    district: "जिला",
    state: "राज्य",
    landSize: "जमीन का आकार (एकड़)",
    soilType: "मिट्टी का प्रकार",
    waterAvailability: "पानी की उपलब्धता",
    preferredLanguage: "पसंदीदा भाषा",
    register: "पंजीकरण करें",
    dashboard: "डैशबोर्ड",
    goodMorning: "नमस्ते",
    weatherToday: "आज का मौसम",
    cropRecommendation: "फसल सलाह",
    waterAdvisory: "सिंचाई सलाह",
    diseaseScanner: "रोग स्कैनर",
    aiAssistant: "AI सहायक",
    onlineMode: "ऑनलाइन मोड सक्रिय",
    offlineMode: "ऑफलाइन मोड सक्रिय",
    offlineDesc: "बुनियादी कृषि सलाह उपलब्ध",
    chatTitle: "AI कृषि सहायक",
    typeMessage: "अपना सवाल लिखें...",
    voiceInput: "आवाज इनपुट",
    cropTitle: "फसल सिफारिश",
    cropSubtitle: "AI से फसल सलाह लें",
    season: "मौसम",
    location: "स्थान",
    getRecommendation: "सिफारिश पाएं",
    waterTitle: "सिंचाई सलाह",
    soilMoisture: "मिट्टी की नमी",
    forecast: "मौसम पूर्वानुमान",
    irrigationRec: "सिंचाई अनुशंसा",
    diseaseTitle: "फसल रोग पहचान",
    uploadImage: "फसल की फोटो अपलोड करें",
    takePhoto: "फोटो लें",
    analyzeImage: "विश्लेषण करें",
    weatherTitle: "मौसम अलर्ट",
    offlineTitle: "ऑफलाइन मोड",
    syncNow: "इंटरनेट आने पर सिंक करें",
    expertTitle: "विशेषज्ञ से जुड़ें",
    contactCenter: "रायथु सेवा केंद्र से संपर्क करें",
    back: "वापस",
    submit: "जमा करें",
    poweredBy: "Gemini AI द्वारा संचालित",
    recommended: "अनुशंसित फसल",
    confidence: "विश्वास",
    treatment: "उपचार",
    diseaseDetected: "रोग पाया गया",
  },
  mr: {
    appName: "कृषी मित्र AI",
    tagline: "तुमच्या भाषेत तुमचा AI शेती सहाय्यक",
    startFarming: "शेती सुरू करा",
    selectLanguage: "भाषा निवडा",
    registration: "शेतकरी नोंदणी",
    name: "पूर्ण नाव",
    phone: "फोन नंबर",
    village: "गाव",
    district: "जिल्हा",
    state: "राज्य",
    landSize: "जमीन क्षेत्र (एकर)",
    soilType: "मातीचा प्रकार",
    waterAvailability: "पाण्याची उपलब्धता",
    preferredLanguage: "पसंतीची भाषा",
    register: "नोंदणी करा",
    dashboard: "डॅशबोर्ड",
    goodMorning: "नमस्कार",
    weatherToday: "आजचे हवामान",
    cropRecommendation: "पीक शिफारस",
    waterAdvisory: "सिंचन सल्ला",
    diseaseScanner: "रोग स्कॅनर",
    aiAssistant: "AI सहाय्यक",
    onlineMode: "ऑनलाइन मोड सक्रिय",
    offlineMode: "ऑफलाइन मोड सक्रिय",
    offlineDesc: "मूलभूत शेती सल्ला उपलब्ध",
    chatTitle: "AI शेती सहाय्यक",
    typeMessage: "तुमचा प्रश्न लिहा...",
    voiceInput: "आवाज इनपुट",
    cropTitle: "पीक शिफारस",
    cropSubtitle: "AI कडून पीक सल्ला घ्या",
    season: "हंगाम",
    location: "स्थान",
    getRecommendation: "शिफारस मिळवा",
    waterTitle: "सिंचन सल्ला",
    soilMoisture: "मातीतील ओलावा",
    forecast: "हवामान अंदाज",
    irrigationRec: "सिंचन शिफारस",
    diseaseTitle: "पीक रोग ओळख",
    uploadImage: "पिकाचा फोटो अपलोड करा",
    takePhoto: "फोटो घ्या",
    analyzeImage: "विश्लेषण करा",
    weatherTitle: "हवामान इशारे",
    offlineTitle: "ऑफलाइन मोड",
    syncNow: "इंटरनेट आल्यावर सिंक करा",
    expertTitle: "तज्ज्ञांशी संपर्क करा",
    contactCenter: "रायतू सेवा केंद्राशी संपर्क करा",
    back: "मागे",
    submit: "सबमिट करा",
    poweredBy: "Gemini AI द्वारे चालवले",
    recommended: "शिफारस केलेले पीक",
    confidence: "विश्वास",
    treatment: "उपचार",
    diseaseDetected: "रोग आढळला",
  },
  te: {
    appName: "కృషి మిత్ర AI",
    tagline: "మీ భాషలో మీ AI వ్యవసాయ సహాయకుడు",
    startFarming: "వ్యవసాయం ప్రారంభించండి",
    selectLanguage: "భాష ఎంచుకోండి",
    registration: "రైతు నమోదు",
    name: "పూర్తి పేరు",
    phone: "ఫోన్ నంబర్",
    village: "గ్రామం",
    district: "జిల్లా",
    state: "రాష్ట్రం",
    landSize: "భూమి పరిమాణం (ఎకరాలు)",
    soilType: "నేల రకం",
    waterAvailability: "నీటి లభ్యత",
    preferredLanguage: "ఇష్టమైన భాష",
    register: "నమోదు చేయండి",
    dashboard: "డాష్‌బోర్డ్",
    goodMorning: "నమస్కారం",
    weatherToday: "నేటి వాతావరణం",
    cropRecommendation: "పంట సిఫారసు",
    waterAdvisory: "నీటిపారుదల సలహా",
    diseaseScanner: "వ్యాధి స్కానర్",
    aiAssistant: "AI సహాయకుడు",
    onlineMode: "ఆన్‌లైన్ మోడ్ యాక్టివ్",
    offlineMode: "ఆఫ్‌లైన్ మోడ్ యాక్టివ్",
    offlineDesc: "ప్రాథమిక వ్యవసాయ సలహా అందుబాటులో ఉంది",
    chatTitle: "AI వ్యవసాయ సహాయకుడు",
    typeMessage: "మీ ప్రశ్న టైప్ చేయండి...",
    voiceInput: "వాయిస్ ఇన్‌పుట్",
    cropTitle: "పంట సిఫారసు",
    cropSubtitle: "AI నుండి పంట సలహా పొందండి",
    season: "సీజన్",
    location: "స్థానం",
    getRecommendation: "సిఫారసు పొందండి",
    waterTitle: "నీటిపారుదల సలహా",
    soilMoisture: "నేల తేమ",
    forecast: "వాతావరణ అంచనా",
    irrigationRec: "నీటిపారుదల సిఫారసు",
    diseaseTitle: "పంట వ్యాధి గుర్తింపు",
    uploadImage: "పంట చిత్రం అప్‌లోడ్ చేయండి",
    takePhoto: "ఫోటో తీయండి",
    analyzeImage: "విశ్లేషించండి",
    weatherTitle: "వాతావరణ హెచ్చరికలు",
    offlineTitle: "ఆఫ్‌లైన్ మోడ్",
    syncNow: "ఇంటర్నెట్ వచ్చినప్పుడు సింక్ చేయండి",
    expertTitle: "నిపుణుడితో కనెక్ట్ అవ్వండి",
    contactCenter: "రైతు సేవా కేంద్రాన్ని సంప్రదించండి",
    back: "వెనుకకు",
    submit: "సమర్పించండి",
    poweredBy: "Gemini AI ద్వారా నడపబడుతోంది",
    recommended: "సిఫారసు చేసిన పంట",
    confidence: "నమ్మకం",
    treatment: "చికిత్స",
    diseaseDetected: "వ్యాధి గుర్తించబడింది",
  },
  ta: {
    appName: "கிருஷி மித்ரா AI",
    tagline: "உங்கள் மொழியில் உங்கள் AI விவசாய உதவியாளர்",
    startFarming: "விவசாயம் தொடங்குங்கள்",
    selectLanguage: "மொழி தேர்ந்தெடுக்கவும்",
    registration: "விவசாயி பதிவு",
    name: "முழு பெயர்",
    phone: "தொலைபேசி எண்",
    village: "கிராமம்",
    district: "மாவட்டம்",
    state: "மாநிலம்",
    landSize: "நிலம் அளவு (ஏக்கர்)",
    soilType: "மண் வகை",
    waterAvailability: "நீர் கிடைக்கும் தன்மை",
    preferredLanguage: "விரும்பும் மொழி",
    register: "பதிவு செய்யுங்கள்",
    dashboard: "டாஷ்போர்டு",
    goodMorning: "வணக்கம்",
    weatherToday: "இன்றைய வானிலை",
    cropRecommendation: "பயிர் பரிந்துரை",
    waterAdvisory: "நீர்ப்பாசன ஆலோசனை",
    diseaseScanner: "நோய் ஸ்கேனர்",
    aiAssistant: "AI உதவியாளர்",
    onlineMode: "ஆன்லைன் முறை செயல்படுகிறது",
    offlineMode: "ஆஃப்லைன் முறை செயல்படுகிறது",
    offlineDesc: "அடிப்படை விவசாய ஆலோசனை கிடைக்கும்",
    chatTitle: "AI விவசாய உதவியாளர்",
    typeMessage: "உங்கள் கேள்வியை தட்டச்சு செய்யுங்கள்...",
    voiceInput: "குரல் உள்ளீடு",
    cropTitle: "பயிர் பரிந்துரை",
    cropSubtitle: "AI இலிருந்து பயிர் ஆலோசனை பெறுங்கள்",
    season: "பருவகாலம்",
    location: "இடம்",
    getRecommendation: "பரிந்துரை பெறுங்கள்",
    waterTitle: "நீர்ப்பாசன ஆலோசனை",
    soilMoisture: "மண் ஈரப்பதம்",
    forecast: "வானிலை முன்னறிவிப்பு",
    irrigationRec: "நீர்ப்பாசன பரிந்துரை",
    diseaseTitle: "பயிர் நோய் கண்டறிதல்",
    uploadImage: "பயிர் படம் பதிவேற்றவும்",
    takePhoto: "புகைப்படம் எடுக்கவும்",
    analyzeImage: "பகுப்பாய்வு செய்யுங்கள்",
    weatherTitle: "வானிலை எச்சரிக்கைகள்",
    offlineTitle: "ஆஃப்லைன் முறை",
    syncNow: "இணையம் வரும்போது ஒத்திசைக்கவும்",
    expertTitle: "நிபுணரிடம் தொடர்பு கொள்ளுங்கள்",
    contactCenter: "ரைதா சேவா கேந்திரத்தை தொடர்பு கொள்ளுங்கள்",
    back: "திரும்பு",
    submit: "சமர்பிக்கவும்",
    poweredBy: "Gemini AI ஆல் இயக்கப்படுகிறது",
    recommended: "பரிந்துரைக்கப்பட்ட பயிர்",
    confidence: "நம்பகத்தன்மை",
    treatment: "சிகிச்சை",
    diseaseDetected: "நோய் கண்டறியப்பட்டது",
  },
  kn: {
    appName: "ಕೃಷಿ ಮಿತ್ರ AI",
    tagline: "ನಿಮ್ಮ ಭಾಷೆಯಲ್ಲಿ ನಿಮ್ಮ AI ಕೃಷಿ ಸಹಾಯಕ",
    startFarming: "ಕೃಷಿ ಪ್ರಾರಂಭಿಸಿ",
    selectLanguage: "ಭಾಷೆ ಆಯ್ಕೆ ಮಾಡಿ",
    registration: "ರೈತ ನೋಂದಣಿ",
    name: "ಪೂರ್ಣ ಹೆಸರು",
    phone: "ಫೋನ್ ಸಂಖ್ಯೆ",
    village: "ಗ್ರಾಮ",
    district: "ಜಿಲ್ಲೆ",
    state: "ರಾಜ್ಯ",
    landSize: "ಭೂಮಿ ಗಾತ್ರ (ಎಕರೆ)",
    soilType: "ಮಣ್ಣಿನ ಪ್ರಕಾರ",
    waterAvailability: "ನೀರಿನ ಲಭ್ಯತೆ",
    preferredLanguage: "ಆದ್ಯತಾ ಭಾಷೆ",
    register: "ನೋಂದಾಯಿಸಿ",
    dashboard: "ಡ್ಯಾಶ್‌ಬೋರ್ಡ್",
    goodMorning: "ನಮಸ್ಕಾರ",
    weatherToday: "ಇಂದಿನ ಹವಾಮಾನ",
    cropRecommendation: "ಬೆಳೆ ಶಿಫಾರಸು",
    waterAdvisory: "ನೀರಾವರಿ ಸಲಹೆ",
    diseaseScanner: "ರೋಗ ಸ್ಕ್ಯಾನರ್",
    aiAssistant: "AI ಸಹಾಯಕ",
    onlineMode: "ಆನ್‌ಲೈನ್ ಮೋಡ್ ಸಕ್ರಿಯ",
    offlineMode: "ಆಫ್‌ಲೈನ್ ಮೋಡ್ ಸಕ್ರಿಯ",
    offlineDesc: "ಮೂಲ ಕೃಷಿ ಸಲಹೆ ಲಭ್ಯವಿದೆ",
    chatTitle: "AI ಕೃಷಿ ಸಹಾಯಕ",
    typeMessage: "ನಿಮ್ಮ ಪ್ರಶ್ನೆ ಟೈಪ್ ಮಾಡಿ...",
    voiceInput: "ಧ್ವನಿ ಇನ್‌ಪುಟ್",
    cropTitle: "ಬೆಳೆ ಶಿಫಾರಸು",
    cropSubtitle: "AI ನಿಂದ ಬೆಳೆ ಸಲಹೆ ಪಡೆಯಿರಿ",
    season: "ಋತು",
    location: "ಸ್ಥಳ",
    getRecommendation: "ಶಿಫಾರಸು ಪಡೆಯಿರಿ",
    waterTitle: "ನೀರಾವರಿ ಸಲಹೆ",
    soilMoisture: "ಮಣ್ಣಿನ ತೇವಾಂಶ",
    forecast: "ಹವಾಮಾನ ಮುನ್ಸೂಚನೆ",
    irrigationRec: "ನೀರಾವರಿ ಶಿಫಾರಸು",
    diseaseTitle: "ಬೆಳೆ ರೋಗ ಪತ್ತೆ",
    uploadImage: "ಬೆಳೆ ಚಿತ್ರ ಅಪ್‌ಲೋಡ್ ಮಾಡಿ",
    takePhoto: "ಫೋಟೋ ತೆಗೆಯಿರಿ",
    analyzeImage: "ವಿಶ್ಲೇಷಿಸಿ",
    weatherTitle: "ಹವಾಮಾನ ಎಚ್ಚರಿಕೆಗಳು",
    offlineTitle: "ಆಫ್‌ಲೈನ್ ಮೋಡ್",
    syncNow: "ಇಂಟರ್ನೆಟ್ ಬಂದಾಗ ಸಿಂಕ್ ಮಾಡಿ",
    expertTitle: "ತಜ್ಞರೊಂದಿಗೆ ಸಂಪರ್ಕಿಸಿ",
    contactCenter: "ರೈತ ಸೇವಾ ಕೇಂದ್ರ ಸಂಪರ್ಕಿಸಿ",
    back: "ಹಿಂದೆ",
    submit: "ಸಲ್ಲಿಸಿ",
    poweredBy: "Gemini AI ಮೂಲಕ ಚಾಲಿತ",
    recommended: "ಶಿಫಾರಸು ಮಾಡಿದ ಬೆಳೆ",
    confidence: "ವಿಶ್ವಾಸ",
    treatment: "ಚಿಕಿತ್ಸೆ",
    diseaseDetected: "ರೋಗ ಪತ್ತೆಯಾಯಿತು",
  },
}

const defaultFarmer: FarmerProfile = {
  name: "Ramesh Patil",
  phone: "+91 98765 43210",
  village: "Shirdi",
  district: "Ahmednagar",
  state: "Maharashtra",
  landSize: "3.5",
  soilType: "Black Soil",
  waterAvailability: "Medium",
  language: "en",
}

const AppContext = createContext<AppContextType | undefined>(undefined)

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [screen, setScreen] = useState<Screen>("splash")
  const [language, setLanguage] = useState<Language>("en")
  const [farmer, setFarmer] = useState<FarmerProfile>(defaultFarmer)
  const [isOnline] = useState(true)

  const t = (key: string): string => {
    return translations[language]?.[key] ?? translations["en"][key] ?? key
  }

  return (
    <AppContext.Provider
      value={{ screen, setScreen, language, setLanguage, farmer, setFarmer, isOnline, t }}
    >
      {children}
    </AppContext.Provider>
  )
}

export function useApp() {
  const ctx = useContext(AppContext)
  if (!ctx) throw new Error("useApp must be used within AppProvider")
  return ctx
}

export const LANGUAGES: { code: Language; label: string; native: string }[] = [
  { code: "en", label: "English", native: "English" },
  { code: "hi", label: "Hindi", native: "हिंदी" },
  { code: "mr", label: "Marathi", native: "मराठी" },
  { code: "te", label: "Telugu", native: "తెలుగు" },
  { code: "ta", label: "Tamil", native: "தமிழ்" },
  { code: "kn", label: "Kannada", native: "ಕನ್ನಡ" },
]

export const SOIL_TYPES = ["Black Soil", "Red Soil", "Alluvial Soil", "Sandy Soil", "Clay Soil", "Loamy Soil"]
export const SEASONS = ["Kharif (June-Oct)", "Rabi (Nov-Apr)", "Zaid (Mar-Jun)"]
export const WATER_AVAILABILITY = ["High (Canal/River)", "Medium (Borewell)", "Low (Rainfed)", "Very Low"]
