import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:krishi_mitra/providers/app_provider.dart';
import 'package:krishi_mitra/providers/farmer_provider.dart';
import 'package:krishi_mitra/screens/splash_screen.dart';
import 'package:krishi_mitra/screens/registration_screen.dart';
import 'package:krishi_mitra/screens/dashboard_screen.dart';
import 'package:krishi_mitra/theme/app_theme.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => AppProvider()),
        ChangeNotifierProvider(create: (_) => FarmerProvider()),
      ],
      child: MaterialApp(
        title: 'KrishiMitra AI',
        theme: AppTheme.lightTheme,
        darkTheme: AppTheme.darkTheme,
        themeMode: ThemeMode.light,
        home: const SplashScreen(),
        routes: {
          '/splash': (_) => const SplashScreen(),
          '/registration': (_) => const RegistrationScreen(),
          '/dashboard': (_) => const DashboardScreen(),
        },
      ),
    );
  }
}
