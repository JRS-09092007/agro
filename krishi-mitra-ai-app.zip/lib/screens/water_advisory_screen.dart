import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:krishi_mitra/providers/app_provider.dart';
import 'package:krishi_mitra/services/api_service.dart';
import 'package:krishi_mitra/theme/app_theme.dart';

class WaterAdvisoryScreen extends StatefulWidget {
  const WaterAdvisoryScreen({Key? key}) : super(key: key);

  @override
  State<WaterAdvisoryScreen> createState() => _WaterAdvisoryScreenState();
}

class _WaterAdvisoryScreenState extends State<WaterAdvisoryScreen> {
  late ApiService _apiService;

  @override
  void initState() {
    super.initState();
    _apiService = ApiService();
  }

  @override
  Widget build(BuildContext context) {
    final appProvider = Provider.of<AppProvider>(context);
    final waterAdviceAI = _apiService.generateAIResponse(
      appProvider.language,
      'water_advice',
      {},
    );

    return Scaffold(
      appBar: AppBar(
        title: Text(appProvider.t('water_advisory')),
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // AI Water Advice
            Container(
              padding: const EdgeInsets.all(16),
              decoration: BoxDecoration(
                color: AppTheme.skyBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(16),
                border: Border.all(
                  color: AppTheme.skyBlue.withOpacity(0.3),
                ),
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.lightbulb_outline,
                          color: AppTheme.skyBlue, size: 20),
                      const SizedBox(width: 8),
                      Text(
                        appProvider.t('ai_advice'),
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                          color: AppTheme.skyBlue,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    waterAdviceAI,
                    style: const TextStyle(
                      fontSize: 13,
                      height: 1.6,
                      color: AppTheme.darkGray,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),
            // Soil Moisture Gauge
            Container(
              padding: const EdgeInsets.all(20),
              decoration: BoxDecoration(
                color: AppTheme.white,
                borderRadius: BorderRadius.circular(16),
                boxShadow: [
                  BoxShadow(
                    color: Colors.black.withOpacity(0.08),
                    blurRadius: 12,
                  ),
                ],
              ),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    appProvider.t('soil_moisture_level'),
                    style: const TextStyle(
                      fontSize: 16,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 16),
                  Center(
                    child: Column(
                      children: [
                        Stack(
                          alignment: Alignment.center,
                          children: [
                            SizedBox(
                              width: 120,
                              height: 120,
                              child: CircularProgressIndicator(
                                value: 0.65,
                                strokeWidth: 8,
                                valueColor: const AlwaysStoppedAnimation<Color>(
                                  AppTheme.skyBlue,
                                ),
                                backgroundColor: AppTheme.lightGray,
                              ),
                            ),
                            const Column(
                              mainAxisAlignment: MainAxisAlignment.center,
                              children: [
                                Text(
                                  '65%',
                                  style: TextStyle(
                                    fontSize: 28,
                                    fontWeight: FontWeight.bold,
                                  ),
                                ),
                                Text(
                                  'Optimal',
                                  style: TextStyle(
                                    fontSize: 12,
                                    color: AppTheme.mediumGray,
                                  ),
                                ),
                              ],
                            ),
                          ],
                        ),
                        const SizedBox(height: 12),
                        const Text(
                          'Last updated: Today at 9:30 AM',
                          style: TextStyle(
                            fontSize: 12,
                            color: AppTheme.mediumGray,
                          ),
                        ),
                      ],
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 24),

            // 5-Day Forecast
            Text(
              appProvider.t('water_forecast'),
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            ..._buildForecastDays(),
            const SizedBox(height: 24),

            // Daily Irrigation Schedule
            Text(
              appProvider.t('irrigation_schedule'),
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            ..._buildIrrigationSchedule(appProvider),
            const SizedBox(height: 24),

            // Water Saving Tips
            Text(
              appProvider.t('water_saving_tips'),
              style: const TextStyle(
                fontSize: 18,
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 12),
            ..._buildTips(appProvider),
          ],
        ),
      ),
    );
  }

  List<Widget> _buildForecastDays() {
    final days = [
      ('Today', 'Light', '15mm', '🌤️'),
      ('Tomorrow', 'Moderate', '20mm', '⛅'),
      ('Day 3', 'Moderate', '18mm', '⛅'),
      ('Day 4', 'Heavy', '35mm', '🌧️'),
      ('Day 5', 'Light', '8mm', '☀️'),
    ];

    return days
        .map((day) => Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.white,
                borderRadius: BorderRadius.circular(12),
                border: Border.all(color: AppTheme.lightGray),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        day.$1,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        day.$2,
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppTheme.mediumGray,
                        ),
                      ),
                    ],
                  ),
                  Row(
                    children: [
                      Text(
                        day.$3,
                        style: const TextStyle(
                          fontSize: 14,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      const SizedBox(width: 8),
                      Text(day.$4, style: const TextStyle(fontSize: 20)),
                    ],
                  ),
                ],
              ),
            ))
        .toList();
  }

  List<Widget> _buildIrrigationSchedule(AppProvider appProvider) {
    final schedule = [
      ('05:30 AM', appProvider.t('light_irrigation'), '30 mins', '🌅'),
      ('02:00 PM', appProvider.t('heavy_irrigation'), '60 mins', '☀️'),
      ('06:00 PM', appProvider.t('light_irrigation'), '30 mins', '🌆'),
    ];

    return schedule
        .map((item) => Container(
              margin: const EdgeInsets.only(bottom: 8),
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.skyBlue.withOpacity(0.1),
                borderRadius: BorderRadius.circular(12),
                border: Border.all(
                  color: AppTheme.skyBlue.withOpacity(0.3),
                ),
              ),
              child: Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Text(item.$4, style: const TextStyle(fontSize: 18)),
                          const SizedBox(width: 8),
                          Text(
                            item.$1,
                            style: const TextStyle(
                              fontSize: 14,
                              fontWeight: FontWeight.w600,
                            ),
                          ),
                        ],
                      ),
                      Text(
                        item.$2,
                        style: const TextStyle(
                          fontSize: 12,
                          color: AppTheme.mediumGray,
                        ),
                      ),
                    ],
                  ),
                  Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
                    decoration: BoxDecoration(
                      color: AppTheme.skyBlue,
                      borderRadius: BorderRadius.circular(6),
                    ),
                    child: Text(
                      item.$3,
                      style: const TextStyle(
                        fontSize: 12,
                        color: AppTheme.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ],
              ),
            ))
        .toList();
  }

  List<Widget> _buildTips(AppProvider appProvider) {
    final tips = [
      appProvider.t('tip_drip_irrigation'),
      appProvider.t('tip_irrigation_time'),
      appProvider.t('tip_mulch_fields'),
      appProvider.t('tip_check_moisture'),
      appProvider.t('tip_avoid_rainfall'),
    ];

    return tips
        .map((tip) => Padding(
              padding: const EdgeInsets.only(bottom: 8),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    '✓',
                    style: TextStyle(
                      fontSize: 16,
                      color: AppTheme.primaryGreen,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      tip,
                      style: const TextStyle(
                        fontSize: 14,
                        color: AppTheme.darkGray,
                      ),
                    ),
                  ),
                ],
              ),
            ))
        .toList();
  }
}
