import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:krishi_mitra/providers/app_provider.dart';
import 'package:krishi_mitra/providers/farmer_provider.dart';
import 'package:krishi_mitra/services/api_service.dart';
import 'package:krishi_mitra/theme/app_theme.dart';
import 'package:krishi_mitra/screens/ai_chat_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({Key? key}) : super(key: key);

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late ApiService _apiService;
  WeatherData? _weatherData;
  bool _isLoading = true;

  @override
  void initState() {
    super.initState();
    _apiService = ApiService();
    _loadWeatherData();
  }

  Future<void> _loadWeatherData() async {
    final farmer = Provider.of<FarmerProvider>(context, listen: false).farmer;
    if (farmer != null) {
      final weather = await _apiService.getWeatherData(farmer.latitude, farmer.longitude);
      setState(() {
        _weatherData = weather;
        _isLoading = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    final appProvider = Provider.of<AppProvider>(context);
    final farmerProvider = Provider.of<FarmerProvider>(context);
    final farmer = farmerProvider.farmer;

    if (farmer == null) {
      return const Scaffold(body: Center(child: Text('No farmer data')));
    }

    return Scaffold(
      body: Stack(
        children: [
          // Green header background
          Container(
            height: 200,
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                colors: [AppTheme.primaryGreen, Color(0xFF2D7F3D)],
              ),
            ),
          ),
          // Main content
          SafeArea(
            child: SingleChildScrollView(
              child: Column(
                children: [
                  // Header with language selector
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 12),
                    child: Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Text(
                          appProvider.t('dashboard'),
                          style: const TextStyle(
                            fontSize: 28,
                            fontWeight: FontWeight.bold,
                            color: AppTheme.white,
                            fontFamily: 'Poppins',
                          ),
                        ),
                        PopupMenuButton<String>(
                          onSelected: (lang) {
                            appProvider.setLanguage(lang);
                          },
                          child: Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 6),
                            decoration: BoxDecoration(
                              color: Colors.white.withOpacity(0.2),
                              borderRadius: BorderRadius.circular(20),
                            ),
                            child: Row(
                              mainAxisSize: MainAxisSize.min,
                              children: [
                                const Icon(Icons.language,
                                    color: Colors.white, size: 16),
                                const SizedBox(width: 4),
                                Text(
                                  appProvider.language == 'en' ? 'EN' :
                                  appProvider.language == 'hi' ? 'HI' :
                                  appProvider.language == 'mr' ? 'MR' :
                                  appProvider.language == 'te' ? 'TE' :
                                  appProvider.language == 'ta' ? 'TA' : 'KN',
                                  style: const TextStyle(
                                    color: Colors.white,
                                    fontWeight: FontWeight.w600,
                                    fontSize: 12,
                                  ),
                                ),
                              ],
                            ),
                          ),
                          itemBuilder: (context) => [
                            const PopupMenuItem(value: 'en', child: Text('English')),
                            const PopupMenuItem(value: 'hi', child: Text('हिंदी')),
                            const PopupMenuItem(value: 'mr', child: Text('मराठी')),
                            const PopupMenuItem(value: 'te', child: Text('తెలుగు')),
                            const PopupMenuItem(value: 'ta', child: Text('தமிழ்')),
                            const PopupMenuItem(value: 'kn', child: Text('ಕನ್ನಡ')),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 12),

                  // Farmer greeting card
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Container(
                      padding: const EdgeInsets.all(16),
                      decoration: BoxDecoration(
                        color: AppTheme.white,
                        borderRadius: BorderRadius.circular(16),
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.08),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          ),
                        ],
                      ),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          Text(
                            'Namaste, ${farmer.name.split(' ')[0]} 🙏',
                            style: const TextStyle(
                              fontSize: 18,
                              fontWeight: FontWeight.w600,
                              fontFamily: 'Poppins',
                            ),
                          ),
                          const SizedBox(height: 8),
                          Text(
                            '${farmer.village} • ${farmer.landSize} acres • ${farmer.soilType} soil',
                            style: const TextStyle(
                              fontSize: 12,
                              color: AppTheme.mediumGray,
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),

                  // Weather card
                  if (_weatherData != null)
                    Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 16),
                      child: _buildWeatherCard(_weatherData!),
                    ),
                  const SizedBox(height: 16),

                  // Services grid
                  Padding(
                    padding: const EdgeInsets.symmetric(horizontal: 16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          'Services',
                          style: Theme.of(context).textTheme.headlineSmall,
                        ),
                        const SizedBox(height: 12),
                        GridView.count(
                          crossAxisCount: 2,
                          shrinkWrap: true,
                          physics: const NeverScrollableScrollPhysics(),
                          mainAxisSpacing: 12,
                          crossAxisSpacing: 12,
                          children: [
                            _buildServiceCard(
                              icon: Icons.eco,
                              label: appProvider.t('crop_recommendation'),
                              color: AppTheme.primaryGreen,
                              onTap: () {},
                            ),
                            _buildServiceCard(
                              icon: Icons.water_drop,
                              label: appProvider.t('water_advisory'),
                              color: AppTheme.skyBlue,
                              onTap: () {},
                            ),
                            _buildServiceCard(
                              icon: Icons.bug_report,
                              label: appProvider.t('disease_detection'),
                              color: AppTheme.earthBrown,
                              onTap: () {},
                            ),
                            _buildServiceCard(
                              icon: Icons.cloud,
                              label: appProvider.t('weather_alerts'),
                              color: AppTheme.accentGold,
                              onTap: () {},
                            ),
                            _buildServiceCard(
                              icon: Icons.chat_bubble,
                              label: appProvider.t('ai_chat'),
                              color: AppTheme.skyBlue,
                              onTap: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => const AIChatScreen(),
                                  ),
                                );
                              },
                            ),
                            _buildServiceCard(
                              icon: Icons.phone,
                              label: appProvider.t('expert_connect'),
                              color: AppTheme.primaryGreen,
                              onTap: () {},
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildWeatherCard(WeatherData weather) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(16),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 12,
            offset: const Offset(0, 4),
          ),
        ],
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              const Text(
                'Current Weather',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: AppTheme.lightGray,
                  borderRadius: BorderRadius.circular(8),
                ),
                child: Text(
                  weather.condition,
                  style: const TextStyle(fontSize: 12),
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceAround,
            children: [
              _buildWeatherStat('🌡️ Temp', weather.temp),
              _buildWeatherStat('💧 Humidity', weather.humidity),
              _buildWeatherStat('💨 Wind', weather.windSpeed),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildWeatherStat(String label, String value) {
    return Column(
      children: [
        Text(label, style: const TextStyle(fontSize: 12)),
        const SizedBox(height: 4),
        Text(
          value,
          style: const TextStyle(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ],
    );
  }

  Widget _buildServiceCard({
    required IconData icon,
    required String label,
    required Color color,
    required VoidCallback onTap,
  }) {
    return Container(
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 8,
            offset: const Offset(0, 2),
          ),
        ],
      ),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(12),
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Container(
                  width: 50,
                  height: 50,
                  decoration: BoxDecoration(
                    color: color.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Icon(icon, color: color, size: 28),
                ),
                const SizedBox(height: 12),
                Text(
                  label,
                  textAlign: TextAlign.center,
                  style: const TextStyle(
                    fontSize: 12,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
