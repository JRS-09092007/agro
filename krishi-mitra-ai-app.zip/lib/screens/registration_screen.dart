import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:geolocator/geolocator.dart';
import 'package:krishi_mitra/providers/app_provider.dart';
import 'package:krishi_mitra/providers/farmer_provider.dart';
import 'package:krishi_mitra/theme/app_theme.dart';

class RegistrationScreen extends StatefulWidget {
  const RegistrationScreen({Key? key}) : super(key: key);

  @override
  State<RegistrationScreen> createState() => _RegistrationScreenState();
}

class _RegistrationScreenState extends State<RegistrationScreen> {
  final _nameController = TextEditingController();
  final _villageController = TextEditingController();
  final _landSizeController = TextEditingController();
  
  String? _selectedSoilType;
  String? _selectedWaterSource;
  double _latitude = 0;
  double _longitude = 0;
  bool _isLoading = false;

  final _soilTypes = ['Loamy', 'Black', 'Red', 'Alluvial', 'Sandy'];
  final _waterSources = ['Well', 'Bore', 'Canal', 'River', 'Tank'];

  @override
  void dispose() {
    _nameController.dispose();
    _villageController.dispose();
    _landSizeController.dispose();
    super.dispose();
  }

  Future<void> _getLocation() async {
    try {
      setState(() => _isLoading = true);
      
      final permission = await Geolocator.requestPermission();
      if (permission == LocationPermission.denied ||
          permission == LocationPermission.deniedForever) {
        if (mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Location permission denied')),
          );
        }
        setState(() => _isLoading = false);
        return;
      }

      final position = await Geolocator.getCurrentPosition();
      setState(() {
        _latitude = position.latitude;
        _longitude = position.longitude;
        _isLoading = false;
      });
    } catch (e) {
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Error: $e')),
        );
      }
      setState(() => _isLoading = false);
    }
  }

  Future<void> _register() async {
    if (_nameController.text.isEmpty ||
        _villageController.text.isEmpty ||
        _landSizeController.text.isEmpty ||
        _selectedSoilType == null ||
        _selectedWaterSource == null) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Please fill all fields')),
      );
      return;
    }

    final farmer = FarmerData(
      name: _nameController.text,
      village: _villageController.text,
      landSize: double.parse(_landSizeController.text),
      soilType: _selectedSoilType!,
      waterSource: _selectedWaterSource!,
      latitude: _latitude,
      longitude: _longitude,
    );

    await Provider.of<FarmerProvider>(context, listen: false)
        .registerFarmer(farmer);

    if (mounted) {
      Navigator.of(context).pushReplacementNamed('/dashboard');
    }
  }

  @override
  Widget build(BuildContext context) {
    final appProvider = Provider.of<AppProvider>(context);
    
    return Scaffold(
      appBar: AppBar(
        title: Text(appProvider.t('register')),
        elevation: 0,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(20),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            // Name field
            TextField(
              controller: _nameController,
              decoration: InputDecoration(
                labelText: appProvider.t('farmer_name'),
                prefixIcon: const Icon(Icons.person),
              ),
            ),
            const SizedBox(height: 16),

            // Village field
            TextField(
              controller: _villageController,
              decoration: InputDecoration(
                labelText: appProvider.t('village'),
                prefixIcon: const Icon(Icons.location_on),
              ),
            ),
            const SizedBox(height: 16),

            // Land size field
            TextField(
              controller: _landSizeController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: appProvider.t('land_size'),
                prefixIcon: const Icon(Icons.landscape),
              ),
            ),
            const SizedBox(height: 16),

            // Soil type dropdown
            DropdownButtonFormField<String>(
              value: _selectedSoilType,
              decoration: InputDecoration(
                labelText: appProvider.t('soil_type'),
                prefixIcon: const Icon(Icons.science),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              items: _soilTypes
                  .map((type) => DropdownMenuItem(value: type, child: Text(type)))
                  .toList(),
              onChanged: (value) => setState(() => _selectedSoilType = value),
            ),
            const SizedBox(height: 16),

            // Water source dropdown
            DropdownButtonFormField<String>(
              value: _selectedWaterSource,
              decoration: InputDecoration(
                labelText: appProvider.t('water_source'),
                prefixIcon: const Icon(Icons.water_drop),
                border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(12),
                ),
              ),
              items: _waterSources
                  .map((source) =>
                      DropdownMenuItem(value: source, child: Text(source)))
                  .toList(),
              onChanged: (value) => setState(() => _selectedWaterSource = value),
            ),
            const SizedBox(height: 16),

            // Location status
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.lightGray,
                borderRadius: BorderRadius.circular(12),
              ),
              child: Row(
                children: [
                  Icon(
                    _latitude == 0 ? Icons.location_off : Icons.location_on,
                    color: _latitude == 0
                        ? AppTheme.mediumGray
                        : AppTheme.primaryGreen,
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: Text(
                      _latitude == 0
                          ? 'Location not set'
                          : '${_latitude.toStringAsFixed(4)}, ${_longitude.toStringAsFixed(4)}',
                      style: TextStyle(
                        color: _latitude == 0
                            ? AppTheme.mediumGray
                            : AppTheme.darkGray,
                      ),
                    ),
                  ),
                  if (_isLoading)
                    const SizedBox(
                      width: 20,
                      height: 20,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  else
                    ElevatedButton(
                      onPressed: _getLocation,
                      style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 12, vertical: 8),
                        backgroundColor: AppTheme.skyBlue,
                      ),
                      child: const Text('Get Location',
                          style: TextStyle(fontSize: 12)),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 32),

            // Register button
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _register,
                style: ElevatedButton.styleFrom(
                  padding: const EdgeInsets.symmetric(vertical: 16),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(12),
                  ),
                ),
                child: Text(
                  appProvider.t('register'),
                  style: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
