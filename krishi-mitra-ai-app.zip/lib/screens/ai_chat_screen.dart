import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:krishi_mitra/providers/app_provider.dart';
import 'package:krishi_mitra/providers/farmer_provider.dart';
import 'package:krishi_mitra/services/gemini_ai_service.dart';
import 'package:krishi_mitra/services/voice_service.dart';
import 'package:krishi_mitra/theme/app_theme.dart';
import 'dart:io' show Platform;

class Message {
  final String id;
  final String text;
  final bool isUser;
  final DateTime timestamp;

  Message({
    required this.id,
    required this.text,
    required this.isUser,
    required this.timestamp,
  });
}

class AIChatScreen extends StatefulWidget {
  const AIChatScreen({Key? key}) : super(key: key);

  @override
  State<AIChatScreen> createState() => _AIChatScreenState();
}

class _AIChatScreenState extends State<AIChatScreen> {
  late GeminiAIService _geminiService;
  late VoiceService _voiceService;
  final TextEditingController _messageController = TextEditingController();
  final ScrollController _scrollController = ScrollController();
  final List<Message> _messages = [];
  bool _isLoading = false;
  bool _isListening = false;

  @override
  void initState() {
    super.initState();
    _initializeServices();
    _initializeChat();
  }

  void _initializeServices() {
    const geminiApiKey = 'YOUR_GEMINI_API_KEY_HERE';
    _geminiService = GeminiAIService(apiKey: geminiApiKey);
    _voiceService = VoiceService();
  }

  void _initializeChat() {
    final appProvider = Provider.of<AppProvider>(context, listen: false);
    final farmerProvider = Provider.of<FarmerProvider>(context, listen: false);
    
    final greeting = appProvider.language == 'en'
        ? 'Welcome to KrishiMitra AI! I\'m here to help with your farming questions.'
        : appProvider.language == 'hi'
            ? 'कृषि मित्र एआई में आपका स्वागत है! मैं आपके खेती के सवालों में मदद करने के लिए यहां हूं।'
            : appProvider.language == 'mr'
                ? 'कृषी मित्र एआईमध्ये आपले स्वागत आहे! मैं आपल्या शेतीच्या प्रश्नांमध्ये मदत करण्यासाठी येथे आहे।'
                : 'Welcome to KrishiMitra AI!';

    _messages.add(
      Message(
        id: '0',
        text: greeting,
        isUser: false,
        timestamp: DateTime.now(),
      ),
    );
    setState(() {});
  }

  Future<void> _sendMessage(String text) async {
    if (text.isEmpty) return;

    final appProvider = Provider.of<AppProvider>(context, listen: false);
    final farmerProvider = Provider.of<FarmerProvider>(context, listen: false);
    
    _messages.add(
      Message(
        id: DateTime.now().millisecondsSinceEpoch.toString(),
        text: text,
        isUser: true,
        timestamp: DateTime.now(),
      ),
    );

    _messageController.clear();
    _scrollToBottom();
    setState(() => _isLoading = true);

    try {
      // Get AI response from Gemini API
      final aiResponse = await _geminiService.generateFarmingAdvice(
        question: text,
        language: appProvider.language,
        farmerContext: {
          'farmerName': farmerProvider.farmer.name,
          'location': farmerProvider.farmer.village,
          'soilType': farmerProvider.farmer.soilType,
          'landSize': farmerProvider.farmer.landSize.toString(),
          'waterSource': farmerProvider.farmer.waterSource,
        },
      );

      _messages.add(
        Message(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          text: aiResponse,
          isUser: false,
          timestamp: DateTime.now(),
        ),
      );

      // Speak the response in user's language
      await _voiceService.speak(aiResponse, appProvider.language);
    } catch (e) {
      print('[v0] Chat Error: $e');
      _messages.add(
        Message(
          id: DateTime.now().millisecondsSinceEpoch.toString(),
          text: 'Sorry, I encountered an error. Please try again.',
          isUser: false,
          timestamp: DateTime.now(),
        ),
      );
    }

    setState(() => _isLoading = false);
    _scrollToBottom();
  }

  Future<void> _startVoiceInput() async {
    final appProvider = Provider.of<AppProvider>(context, listen: false);
    
    setState(() => _isListening = true);
    
    try {
      final recognizedText = await _voiceService.startListening(appProvider.language);
      
      if (recognizedText != null && recognizedText.isNotEmpty) {
        _messageController.text = recognizedText;
        await _sendMessage(recognizedText);
      }
    } catch (e) {
      print('[v0] Voice Input Error: $e');
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Error with voice input')),
      );
    }
    
    setState(() => _isListening = false);
  }

  Future<void> _stopVoiceInput() async {
    await _voiceService.stopListening();
    setState(() => _isListening = false);
  }

    return 'greeting';
  }

  void _scrollToBottom() {
    Future.delayed(const Duration(milliseconds: 100), () {
      if (_scrollController.hasClients) {
        _scrollController.animateTo(
          _scrollController.position.maxScrollExtent,
          duration: const Duration(milliseconds: 300),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  void dispose() {
    _messageController.dispose();
    _scrollController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final appProvider = Provider.of<AppProvider>(context);
    final farmerProvider = Provider.of<FarmerProvider>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text(appProvider.t('ai_chat')),
        backgroundColor: AppTheme.primaryGreen,
        foregroundColor: AppTheme.white,
        elevation: 0,
        leading: IconButton(
          icon: const Icon(Icons.arrow_back),
          onPressed: () => Navigator.pop(context),
        ),
      ),
      body: Column(
        children: [
          Expanded(
            child: ListView.builder(
              controller: _scrollController,
              padding: const EdgeInsets.all(16),
              itemCount: _messages.length + (_isLoading ? 1 : 0),
              itemBuilder: (context, index) {
                if (index == _messages.length && _isLoading) {
                  return Padding(
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    child: Row(
                      children: [
                        Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: AppTheme.primaryGreen.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Row(
                            mainAxisSize: MainAxisSize.min,
                            children: [
                              SizedBox(
                                width: 16,
                                height: 16,
                                child: CircularProgressIndicator(
                                  strokeWidth: 2,
                                  valueColor: AlwaysStoppedAnimation(
                                    AppTheme.primaryGreen,
                                  ),
                                ),
                              ),
                              const SizedBox(width: 8),
                              Text(
                                appProvider.t('typing'),
                                style: const TextStyle(
                                  fontSize: 12,
                                  color: AppTheme.primaryGreen,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  );
                }

                final message = _messages[index];
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  child: Row(
                    mainAxisAlignment: message.isUser
                        ? MainAxisAlignment.end
                        : MainAxisAlignment.start,
                    children: [
                      Flexible(
                        child: Container(
                          padding: const EdgeInsets.all(12),
                          decoration: BoxDecoration(
                            color: message.isUser
                                ? AppTheme.primaryGreen
                                : AppTheme.primaryGreen.withOpacity(0.1),
                            borderRadius: BorderRadius.circular(12),
                          ),
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text(
                                message.text,
                                style: TextStyle(
                                  fontSize: 14,
                                  color: message.isUser
                                      ? AppTheme.white
                                      : AppTheme.darkGray,
                                  height: 1.5,
                                ),
                              ),
                              const SizedBox(height: 4),
                              Text(
                                _formatTime(message.timestamp),
                                style: TextStyle(
                                  fontSize: 11,
                                  color: message.isUser
                                      ? AppTheme.white.withOpacity(0.7)
                                      : AppTheme.mediumGray,
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  ),
                );
              },
            ),
          ),
          Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: AppTheme.white,
              border: Border(
                top: BorderSide(
                  color: AppTheme.lightGray,
                  width: 1,
                ),
              ),
            ),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _messageController,
                    enabled: !_isLoading,
                    decoration: InputDecoration(
                      hintText: appProvider.t('ask_question'),
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(24),
                      ),
                      contentPadding: const EdgeInsets.symmetric(
                        horizontal: 16,
                        vertical: 10,
                      ),
                      suffixIcon: IconButton(
                        icon: Icon(
                          _isListening ? Icons.mic_outlined : Icons.mic_none,
                          color: _isListening ? AppTheme.primaryGreen : null,
                        ),
                        onPressed: _isLoading
                            ? null
                            : () {
                                if (_isListening) {
                                  _stopVoiceInput();
                                } else {
                                  _startVoiceInput();
                                }
                              },
                      ),
                    ),
                    onSubmitted: (text) => _sendMessage(text),
                  ),
                ),
                const SizedBox(width: 8),
                FloatingActionButton(
                  onPressed:
                      _isLoading ? null : () => _sendMessage(_messageController.text),
                  backgroundColor:
                      _isLoading ? AppTheme.mediumGray : AppTheme.primaryGreen,
                  child: const Icon(Icons.send),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  String _formatTime(DateTime dateTime) {
    return '${dateTime.hour}:${dateTime.minute.toString().padLeft(2, '0')}';
  }
}
