import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:krishi_mitra/providers/app_provider.dart';
import 'package:krishi_mitra/providers/farmer_provider.dart';
import 'package:krishi_mitra/theme/app_theme.dart';

class SplashScreen extends StatefulWidget {
  const SplashScreen({Key? key}) : super(key: key);

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    _checkRegistration();
  }

  Future<void> _checkRegistration() async {
    await Future.delayed(const Duration(seconds: 2));
    
    if (!mounted) return;

    final farmerProvider = Provider.of<FarmerProvider>(context, listen: false);
    
    if (farmerProvider.isRegistered) {
      Navigator.of(context).pushReplacementNamed('/dashboard');
    } else {
      Navigator.of(context).pushReplacementNamed('/registration');
    }
  }

  @override
  Widget build(BuildContext context) {
    final appProvider = Provider.of<AppProvider>(context);
    
    return Scaffold(
      body: Stack(
        children: [
          // Background with gradient
          Container(
            decoration: const BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  AppTheme.primaryGreen,
                  Color(0xFF2D7F3D),
                ],
              ),
            ),
          ),
          // Wheat pattern overlay (simple lines)
          Positioned.fill(
            child: CustomPaint(
              painter: WheatPatternPainter(),
            ),
          ),
          // Content
          Center(
            child: Column(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                // Logo
                Container(
                  width: 100,
                  height: 100,
                  decoration: BoxDecoration(
                    color: Colors.white.withOpacity(0.9),
                    borderRadius: BorderRadius.circular(20),
                    boxShadow: [
                      BoxShadow(
                        color: Colors.black.withOpacity(0.2),
                        blurRadius: 15,
                        offset: const Offset(0, 5),
                      ),
                    ],
                  ),
                  child: const Icon(
                    Icons.eco,
                    size: 50,
                    color: AppTheme.primaryGreen,
                  ),
                ),
                const SizedBox(height: 24),
                // Title
                Text(
                  appProvider.t('app_title'),
                  style: const TextStyle(
                    fontSize: 32,
                    fontWeight: FontWeight.bold,
                    color: AppTheme.white,
                    fontFamily: 'Poppins',
                  ),
                ),
                const SizedBox(height: 8),
                // Subtitle
                Text(
                  appProvider.t('splash_subtitle'),
                  style: const TextStyle(
                    fontSize: 16,
                    color: Colors.white70,
                    fontFamily: 'Inter',
                  ),
                ),
              ],
            ),
          ),
          // Language selector at bottom
          Positioned(
            bottom: 40,
            left: 0,
            right: 0,
            child: Center(
              child: Container(
                padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                decoration: BoxDecoration(
                  color: Colors.white.withOpacity(0.15),
                  borderRadius: BorderRadius.circular(20),
                  backdrop: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
                ),
                child: Row(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    const Icon(Icons.language, color: Colors.white, size: 18),
                    const SizedBox(width: 8),
                    PopupMenuButton<String>(
                      onSelected: (lang) {
                        appProvider.setLanguage(lang);
                      },
                      child: Text(
                        appProvider.language == 'en' ? 'English' :
                        appProvider.language == 'hi' ? 'हिंदी' :
                        appProvider.language == 'mr' ? 'मराठी' :
                        appProvider.language == 'te' ? 'తెలుగు' :
                        appProvider.language == 'ta' ? 'தமிழ்' : 'ಕನ್ನಡ',
                        style: const TextStyle(
                          color: Colors.white,
                          fontWeight: FontWeight.w600,
                          fontSize: 12,
                        ),
                      ),
                      itemBuilder: (context) => [
                        const PopupMenuItem(value: 'en', child: Text('English')),
                        const PopupMenuItem(value: 'hi', child: Text('हिंदी')),
                        const PopupMenuItem(value: 'mr', child: Text('मराठी')),
                        const PopupMenuItem(value: 'te', child: Text('తెలుగు')),
                        const PopupMenuItem(value: 'ta', child: Text('தமிழ்')),
                        const PopupMenuItem(value: 'kn', child: Text('ಕನ್ನಡ')),
                      ],
                    ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

class WheatPatternPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.white.withOpacity(0.08)
      ..strokeWidth = 2;

    for (int i = 0; i < 20; i++) {
      canvas.drawLine(
        Offset(i * 40.0, 0),
        Offset(i * 40.0 + 30, size.height),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(WheatPatternPainter oldDelegate) => false;
}

// Add this import at the top
import 'dart:ui' as ui;
