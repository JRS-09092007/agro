import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:krishi_mitra/providers/app_provider.dart';
import 'package:krishi_mitra/providers/farmer_provider.dart';
import 'package:krishi_mitra/services/api_service.dart';
import 'package:krishi_mitra/theme/app_theme.dart';

class CropRecommendationScreen extends StatefulWidget {
  const CropRecommendationScreen({Key? key}) : super(key: key);

  @override
  State<CropRecommendationScreen> createState() =>
      _CropRecommendationScreenState();
}

class _CropRecommendationScreenState extends State<CropRecommendationScreen> {
  late ApiService _apiService;
  List<CropRecommendation> _recommendations = [];
  bool _isLoading = true;

  String _selectedSeason = 'kharif';
  String _selectedWaterAvailability = 'medium';

  @override
  void initState() {
    super.initState();
    _apiService = ApiService();
    _loadRecommendations();
  }

  Future<void> _loadRecommendations() async {
    final farmer = Provider.of<FarmerProvider>(context, listen: false).farmer;
    if (farmer != null) {
      final recommendations = await _apiService.getCropRecommendations(
        farmer.soilType,
        _selectedSeason,
        _selectedWaterAvailability,
      );
      setState(() {
        _recommendations = recommendations;
        _isLoading = false;
      });
    }
  }

  Future<void> _refreshRecommendations() async {
    setState(() => _isLoading = true);
    await _loadRecommendations();
  }

  @override
  Widget build(BuildContext context) {
    final appProvider = Provider.of<AppProvider>(context);
    
    return Scaffold(
      appBar: AppBar(
        title: Text(appProvider.t('crop_recommendation')),
      ),
      body: _isLoading
          ? const Center(child: CircularProgressIndicator())
          : SingleChildScrollView(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  // Filters
                  Container(
                    padding: const EdgeInsets.all(16),
                    decoration: BoxDecoration(
                      color: AppTheme.white,
                      borderRadius: BorderRadius.circular(12),
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black.withOpacity(0.08),
                          blurRadius: 8,
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          appProvider.t('filters'),
                          style: const TextStyle(
                            fontSize: 16,
                            fontWeight: FontWeight.w600,
                          ),
                        ),
                        const SizedBox(height: 12),
                        DropdownButtonFormField<String>(
                          value: _selectedSeason,
                          decoration: InputDecoration(
                            labelText: appProvider.t('season'),
                            border: const OutlineInputBorder(),
                          ),
                          items: ['kharif', 'rabi', 'summer']
                              .map((s) => DropdownMenuItem(
                                    value: s,
                                    child: Text(s.toUpperCase()),
                                  ))
                              .toList(),
                          onChanged: (value) {
                            setState(() => _selectedSeason = value ?? 'kharif');
                            _refreshRecommendations();
                          },
                        ),
                        const SizedBox(height: 12),
                        DropdownButtonFormField<String>(
                          value: _selectedWaterAvailability,
                          decoration: InputDecoration(
                            labelText: appProvider.t('water_availability'),
                            border: const OutlineInputBorder(),
                          ),
                          items: ['low', 'medium', 'high']
                              .map((w) => DropdownMenuItem(
                                    value: w,
                                    child: Text(w.toUpperCase()),
                                  ))
                              .toList(),
                          onChanged: (value) {
                            setState(
                                () => _selectedWaterAvailability = value ?? 'medium');
                            _refreshRecommendations();
                          },
                        ),
                      ],
                    ),
                  ),
                  const SizedBox(height: 24),

                  // Recommendations list
                  Text(
                    appProvider.t('recommended_crops'),
                    style: const TextStyle(
                      fontSize: 18,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 12),
                  ..._recommendations
                      .map((crop) => _buildCropCard(crop, appProvider))
                      .toList(),
                ],
              ),
            ),
    );
  }

  Widget _buildCropCard(CropRecommendation crop, AppProvider appProvider) {
    // Generate AI response in local language
    final aiResponse = _apiService.generateAIResponse(
      appProvider.language,
      'crop_recommendation',
      {
        'crop': crop.cropName,
        'soil': appProvider.t('soil_type_loamy'),
        'season': crop.season,
        'water': crop.waterNeeded,
      },
    );

    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      decoration: BoxDecoration(
        color: AppTheme.white,
        borderRadius: BorderRadius.circular(12),
        boxShadow: [
          BoxShadow(
            color: Colors.black.withOpacity(0.08),
            blurRadius: 8,
          ),
        ],
      ),
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.spaceBetween,
              children: [
                Text(
                  crop.cropName,
                  style: const TextStyle(
                    fontSize: 18,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                Container(
                  padding:
                      const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppTheme.primaryGreen.withOpacity(0.1),
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    crop.season,
                    style: const TextStyle(
                      fontSize: 12,
                      color: AppTheme.primaryGreen,
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            // AI Response in local language
            Container(
              padding: const EdgeInsets.all(12),
              decoration: BoxDecoration(
                color: AppTheme.primaryGreen.withOpacity(0.05),
                borderRadius: BorderRadius.circular(8),
                border: Border.all(
                  color: AppTheme.primaryGreen.withOpacity(0.2),
                ),
              ),
              child: Text(
                aiResponse,
                style: const TextStyle(
                  fontSize: 13,
                  color: AppTheme.darkGray,
                  height: 1.5,
                ),
              ),
            ),
            const SizedBox(height: 12),
            _buildDetailRow(appProvider.t('water_needed'), crop.waterNeeded),
            _buildDetailRow(appProvider.t('expected_yield'), crop.expectedYield),
            _buildDetailRow(appProvider.t('market_price'), crop.marketPrice),
          ],
        ),
      ),
    );
  }

  Widget _buildDetailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 6),
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceBetween,
        children: [
          Text(
            label,
            style: const TextStyle(fontSize: 13, color: AppTheme.mediumGray),
          ),
          Text(
            value,
            style: const TextStyle(
              fontSize: 13,
              fontWeight: FontWeight.w600,
              color: AppTheme.darkGray,
            ),
          ),
        ],
      ),
    );
  }
}
