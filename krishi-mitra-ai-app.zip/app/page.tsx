"use client"

import { AppProvider, useApp } from "@/lib/app-context"
import { SplashScreen } from "@/components/krishi/splash-screen"
import { RegistrationScreen } from "@/components/krishi/registration-screen"
import { DashboardScreen } from "@/components/krishi/dashboard-screen"
import { ChatScreen } from "@/components/krishi/chat-screen"
import { CropScreen } from "@/components/krishi/crop-screen"
import { WaterScreen } from "@/components/krishi/water-screen"
import { DiseaseScreen } from "@/components/krishi/disease-screen"
import { WeatherScreen } from "@/components/krishi/weather-screen"
import { OfflineScreen } from "@/components/krishi/offline-screen"
import { ExpertScreen } from "@/components/krishi/expert-screen"

function AppScreens() {
  const { screen } = useApp()

  const screens = {
    splash: <SplashScreen />,
    registration: <RegistrationScreen />,
    dashboard: <DashboardScreen />,
    chat: <ChatScreen />,
    crop: <CropScreen />,
    water: <WaterScreen />,
    disease: <DiseaseScreen />,
    weather: <WeatherScreen />,
    offline: <OfflineScreen />,
    expert: <ExpertScreen />,
  }

  return (
    <div className="min-h-screen bg-background">
      {/* Mobile frame for demo */}
      <div className="mx-auto max-w-md min-h-screen relative">
        {screens[screen]}
      </div>
    </div>
  )
}

export default function Home() {
  return (
    <AppProvider>
      <AppScreens />
    </AppProvider>
  )
}
