"use client"

import { useState, useRef, useEffect } from "react"
import { useApp } from "@/lib/app-context"
import { AIChatBubble, VoiceButton, PageHeader } from "@/components/krishi/shared"
import { Send, Sparkles } from "lucide-react"

interface Message {
  id: string
  text: string
  isUser: boolean
  timestamp: string
}

const MOCK_RESPONSES: Record<string, string> = {
  crop: "Based on your Black Soil in Maharashtra and current Kharif season, I recommend Soybean. It thrives in black soil with medium rainfall (600-900mm). Expected yield: 12-15 quintals/acre. Best sowing time: June 15 - July 15.",
  water: "Your soil moisture is currently at 45%. With rainfall forecast in the next 2 days, avoid irrigation today. Next recommended irrigation: Day after tomorrow, 30 minutes per acre using drip system.",
  disease: "Upload a clear photo of affected leaves. Common diseases in Maharashtra Kharif season include Yellow Mosaic Virus in soybean and Leaf Blight in cotton. I can analyze your image instantly.",
  weather: "Tomorrow's forecast for Ahmednagar: Partly cloudy, 28-34°C, 65% humidity. Good conditions for field work. No extreme weather expected this week.",
  default: "I'm your KrishiMitra AI assistant, powered by Gemini. I can help with crop selection, irrigation advice, disease identification, and market prices. What would you like to know today?",
}

function getAIResponse(message: string): string {
  const lower = message.toLowerCase()
  if (lower.includes("crop") || lower.includes("sow") || lower.includes("plant") || lower.includes("grow")) return MOCK_RESPONSES.crop
  if (lower.includes("water") || lower.includes("irrigat") || lower.includes("rain")) return MOCK_RESPONSES.water
  if (lower.includes("disease") || lower.includes("pest") || lower.includes("sick") || lower.includes("yellow") || lower.includes("brown")) return MOCK_RESPONSES.disease
  if (lower.includes("weather") || lower.includes("temperature") || lower.includes("forecast")) return MOCK_RESPONSES.weather
  return MOCK_RESPONSES.default
}

const QUICK_QUESTIONS = [
  "Which crop should I grow?",
  "When to irrigate?",
  "How to identify disease?",
  "Weather forecast",
]

export function ChatScreen() {
  const { setScreen, farmer, t } = useApp()
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      text: `Namaste ${farmer.name.split(" ")[0]}! I'm your AI farming assistant. Ask me anything about your ${farmer.soilType} farm in ${farmer.village}. I can help with crops, irrigation, diseases, and more!`,
      isUser: false,
      timestamp: "Now",
    },
  ])
  const [input, setInput] = useState("")
  const [isTyping, setIsTyping] = useState(false)
  const bottomRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" })
  }, [messages, isTyping])

  const sendMessage = (text: string) => {
    if (!text.trim()) return
    const now = new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" })
    const userMsg: Message = { id: Date.now().toString(), text, isUser: true, timestamp: now }
    setMessages((m) => [...m, userMsg])
    setInput("")
    setIsTyping(true)

    setTimeout(() => {
      const aiMsg: Message = {
        id: (Date.now() + 1).toString(),
        text: getAIResponse(text),
        isUser: false,
        timestamp: new Date().toLocaleTimeString("en-IN", { hour: "2-digit", minute: "2-digit" }),
      }
      setMessages((m) => [...m, aiMsg])
      setIsTyping(false)
    }, 1200)
  }

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter" && !e.nativeEvent.isComposing && e.keyCode !== 229) {
      sendMessage(input)
    }
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <PageHeader
        title={t("chatTitle")}
        subtitle={t("poweredBy")}
        onBack={() => setScreen("dashboard")}
      />

      {/* Quick questions */}
      <div className="bg-card border-b border-border px-4 py-2">
        <div className="flex gap-2 overflow-x-auto pb-1 no-scrollbar">
          {QUICK_QUESTIONS.map((q) => (
            <button
              key={q}
              onClick={() => sendMessage(q)}
              className="flex-shrink-0 rounded-full border border-primary/30 bg-primary/5 px-3 py-1.5 text-xs font-medium text-primary hover:bg-primary/10 transition-colors"
            >
              {q}
            </button>
          ))}
        </div>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto px-4 py-4 space-y-4 pb-24">
        {messages.map((msg) => (
          <AIChatBubble
            key={msg.id}
            message={msg.text}
            isUser={msg.isUser}
            timestamp={msg.timestamp}
            hasVoice={!msg.isUser}
          />
        ))}
        {isTyping && (
          <div className="flex gap-2 items-end max-w-[85%]">
            <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0">
              <Sparkles className="h-4 w-4 text-white" />
            </div>
            <div className="rounded-2xl rounded-tl-sm bg-card border border-border px-4 py-3">
              <div className="flex gap-1 items-center">
                <span className="h-2 w-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "0ms" }} />
                <span className="h-2 w-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "150ms" }} />
                <span className="h-2 w-2 rounded-full bg-muted-foreground animate-bounce" style={{ animationDelay: "300ms" }} />
              </div>
            </div>
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Input bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border p-4 max-w-md mx-auto">
        <div className="flex items-center gap-2">
          <VoiceButton size="sm" />
          <div className="flex-1 flex items-center gap-2 rounded-2xl border border-input bg-background px-4 py-2.5">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder={t("typeMessage")}
              className="flex-1 bg-transparent text-sm text-foreground placeholder:text-muted-foreground focus:outline-none"
            />
          </div>
          <button
            onClick={() => sendMessage(input)}
            disabled={!input.trim()}
            className="h-10 w-10 rounded-full bg-primary flex items-center justify-center text-primary-foreground hover:bg-primary/90 disabled:opacity-40 disabled:cursor-not-allowed transition-all active:scale-95"
          >
            <Send className="h-4 w-4" />
          </button>
        </div>
      </div>
    </div>
  )
}
