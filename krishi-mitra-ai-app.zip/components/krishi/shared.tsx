"use client"

import { Mic, Wifi, WifiOff, ChevronLeft, Volume2, Globe, Check } from "lucide-react"
import { useApp, LANGUAGES } from "@/lib/app-context"
import { cn } from "@/lib/utils"
import { useState } from "react"

// LanguageSwitcher — floating pill that opens a bottom-sheet style dropdown
export function LanguageSwitcher({ variant = "pill" }: { variant?: "pill" | "icon" }) {
  const { language, setLanguage } = useApp()
  const [open, setOpen] = useState(false)
  const current = LANGUAGES.find((l) => l.code === language)

  return (
    <>
      {/* Trigger */}
      <button
        onClick={() => setOpen(true)}
        aria-label="Change language"
        className={cn(
          "flex items-center gap-1.5 rounded-full transition-all duration-150",
          variant === "pill"
            ? "bg-primary/10 px-3 py-1.5 text-xs font-semibold text-primary hover:bg-primary/20"
            : "h-9 w-9 justify-center bg-white/15 text-white hover:bg-white/25"
        )}
      >
        <Globe className="h-3.5 w-3.5 flex-shrink-0" />
        {variant === "pill" && <span>{current?.native}</span>}
      </button>

      {/* Backdrop */}
      {open && (
        <div
          className="fixed inset-0 z-40 bg-black/40 backdrop-blur-sm"
          onClick={() => setOpen(false)}
        />
      )}

      {/* Bottom sheet */}
      {open && (
        <div className="fixed bottom-0 left-0 right-0 z-50 max-w-md mx-auto rounded-t-3xl bg-card border-t border-border shadow-2xl overflow-hidden">
          {/* Handle */}
          <div className="flex justify-center pt-3 pb-1">
            <div className="h-1 w-10 rounded-full bg-muted-foreground/30" />
          </div>

          <div className="px-5 pt-2 pb-3">
            <p className="text-xs font-semibold uppercase tracking-widest text-muted-foreground">
              Select Language / भाषा चुनें
            </p>
          </div>

          <div className="px-3 pb-6 grid grid-cols-2 gap-2">
            {LANGUAGES.map((lang) => {
              const isSelected = language === lang.code
              return (
                <button
                  key={lang.code}
                  onClick={() => { setLanguage(lang.code); setOpen(false) }}
                  className={cn(
                    "flex items-center justify-between rounded-2xl px-4 py-3.5 text-left transition-all duration-150",
                    isSelected
                      ? "bg-primary text-primary-foreground shadow-md"
                      : "bg-muted hover:bg-muted/70 text-foreground"
                  )}
                >
                  <div>
                    <p className={cn("text-sm font-bold", isSelected ? "text-primary-foreground" : "text-foreground")}>
                      {lang.native}
                    </p>
                    <p className={cn("text-xs mt-0.5", isSelected ? "text-primary-foreground/70" : "text-muted-foreground")}>
                      {lang.label}
                    </p>
                  </div>
                  {isSelected && <Check className="h-4 w-4 flex-shrink-0" />}
                </button>
              )
            })}
          </div>
        </div>
      )}
    </>
  )
}

// OfflineIndicator
export function OfflineIndicator() {
  const { isOnline, t } = useApp()
  return (
    <div
      className={cn(
        "flex items-center gap-2 rounded-full px-3 py-1.5 text-xs font-medium",
        isOnline
          ? "bg-primary/10 text-primary"
          : "bg-amber-100 text-amber-700"
      )}
    >
      {isOnline ? (
        <Wifi className="h-3.5 w-3.5" />
      ) : (
        <WifiOff className="h-3.5 w-3.5" />
      )}
      <span>{isOnline ? t("onlineMode") : t("offlineMode")}</span>
    </div>
  )
}

// VoiceButton
interface VoiceButtonProps {
  onPress?: () => void
  size?: "sm" | "md" | "lg"
  active?: boolean
  className?: string
}

export function VoiceButton({ onPress, size = "md", active = false, className }: VoiceButtonProps) {
  const sizeClasses = {
    sm: "h-9 w-9",
    md: "h-12 w-12",
    lg: "h-16 w-16",
  }
  const iconSizes = { sm: 14, md: 20, lg: 26 }

  return (
    <button
      onClick={onPress}
      aria-label="Voice input"
      className={cn(
        "flex items-center justify-center rounded-full transition-all duration-200 shadow-sm",
        active
          ? "bg-destructive text-white animate-pulse"
          : "bg-primary text-primary-foreground hover:bg-primary/90 active:scale-95",
        sizeClasses[size],
        className
      )}
    >
      <Mic size={iconSizes[size]} />
    </button>
  )
}

// BackButton
interface BackButtonProps {
  onClick: () => void
}
export function BackButton({ onClick }: BackButtonProps) {
  const { t } = useApp()
  return (
    <button
      onClick={onClick}
      className="flex items-center gap-1 text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
    >
      <ChevronLeft className="h-4 w-4" />
      {t("back")}
    </button>
  )
}

// PageHeader
interface PageHeaderProps {
  title: string
  subtitle?: string
  onBack?: () => void
  rightElement?: React.ReactNode
}
export function PageHeader({ title, subtitle, onBack, rightElement }: PageHeaderProps) {
  return (
    <header className="sticky top-0 z-10 bg-card border-b border-border px-4 py-3">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-3">
          {onBack && <BackButton onClick={onBack} />}
          <div>
            <h1 className="text-base font-semibold text-foreground font-heading leading-tight">{title}</h1>
            {subtitle && <p className="text-xs text-muted-foreground">{subtitle}</p>}
          </div>
        </div>
        <div className="flex items-center gap-2">
          {rightElement}
          <LanguageSwitcher variant="pill" />
        </div>
      </div>
    </header>
  )
}

// WeatherCard
interface WeatherCardProps {
  temp: string
  condition: string
  location: string
  humidity: string
  wind: string
}
export function WeatherCard({ temp, condition, location, humidity, wind }: WeatherCardProps) {
  return (
    <div className="rounded-2xl bg-sky/10 border border-sky/20 p-4">
      <div className="flex items-start justify-between">
        <div>
          <p className="text-xs text-muted-foreground font-medium">{location}</p>
          <p className="text-4xl font-bold text-foreground font-heading mt-1">{temp}</p>
          <p className="text-sm font-medium text-sky mt-0.5">{condition}</p>
        </div>
        <div className="text-4xl">
          <svg viewBox="0 0 48 48" fill="none" className="h-14 w-14">
            <circle cx="24" cy="20" r="10" fill="#FCD34D" />
            <path d="M8 32c0-4.4 3.6-8 8-8h16c4.4 0 8 3.6 8 8" fill="#E2E8F0" />
            <ellipse cx="24" cy="34" rx="14" ry="6" fill="#CBD5E1" />
          </svg>
        </div>
      </div>
      <div className="mt-3 flex gap-4 text-xs text-muted-foreground">
        <span>Humidity: <strong className="text-foreground">{humidity}</strong></span>
        <span>Wind: <strong className="text-foreground">{wind}</strong></span>
      </div>
    </div>
  )
}

// CropRecommendationCard
interface CropCardProps {
  crop: string
  reason: string
  waterReq: string
  season: string
  benefit: string
}
export function CropRecommendationCard({ crop, reason, waterReq, season, benefit }: CropCardProps) {
  const { t } = useApp()
  return (
    <div className="rounded-2xl bg-primary/5 border border-primary/20 p-4">
      <div className="flex items-center gap-3 mb-3">
        <div className="h-10 w-10 rounded-full bg-primary/15 flex items-center justify-center">
          <svg viewBox="0 0 24 24" fill="none" className="h-5 w-5 text-primary stroke-current">
            <path d="M12 2C8 2 4 6 4 10c0 5.5 8 12 8 12s8-6.5 8-12c0-4-4-8-8-8z" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
            <path d="M12 8v6M9 11l3-3 3 3" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
        <div>
          <p className="text-xs text-muted-foreground">{t("recommended")}</p>
          <p className="text-xl font-bold text-primary font-heading">{crop}</p>
        </div>
      </div>
      <p className="text-sm text-muted-foreground mb-3 leading-relaxed">{reason}</p>
      <div className="grid grid-cols-3 gap-2">
        <div className="rounded-lg bg-card p-2 text-center">
          <p className="text-xs text-muted-foreground">Water</p>
          <p className="text-xs font-semibold text-foreground">{waterReq}</p>
        </div>
        <div className="rounded-lg bg-card p-2 text-center">
          <p className="text-xs text-muted-foreground">Season</p>
          <p className="text-xs font-semibold text-foreground">{season}</p>
        </div>
        <div className="rounded-lg bg-card p-2 text-center">
          <p className="text-xs text-muted-foreground">Benefit</p>
          <p className="text-xs font-semibold text-foreground">{benefit}</p>
        </div>
      </div>
    </div>
  )
}

// DiseaseResultCard
interface DiseaseCardProps {
  disease: string
  confidence: number
  treatment: string[]
  severity: "low" | "medium" | "high"
}
export function DiseaseResultCard({ disease, confidence, treatment, severity }: DiseaseCardProps) {
  const { t } = useApp()
  const severityColor = { low: "text-primary", medium: "text-amber-600", high: "text-destructive" }
  const severityBg = { low: "bg-primary/10", medium: "bg-amber-50", high: "bg-destructive/10" }

  return (
    <div className={cn("rounded-2xl border p-4", severityBg[severity],
      severity === "low" ? "border-primary/20" : severity === "medium" ? "border-amber-200" : "border-destructive/20"
    )}>
      <div className="flex items-center justify-between mb-3">
        <div>
          <p className="text-xs text-muted-foreground">{t("diseaseDetected")}</p>
          <p className={cn("text-lg font-bold font-heading", severityColor[severity])}>{disease}</p>
        </div>
        <div className={cn("rounded-full px-3 py-1", severityBg[severity])}>
          <p className={cn("text-sm font-bold", severityColor[severity])}>{confidence}%</p>
          <p className="text-xs text-muted-foreground text-center">{t("confidence")}</p>
        </div>
      </div>
      <div>
        <p className="text-xs font-semibold text-foreground mb-2">{t("treatment")}:</p>
        <ul className="space-y-1">
          {treatment.map((item, i) => (
            <li key={i} className="flex items-start gap-2 text-xs text-muted-foreground">
              <span className={cn("mt-0.5 h-1.5 w-1.5 rounded-full flex-shrink-0", severityColor[severity].replace("text-", "bg-"))} />
              {item}
            </li>
          ))}
        </ul>
      </div>
    </div>
  )
}

// AIChatBubble
interface ChatBubbleProps {
  message: string
  isUser: boolean
  timestamp?: string
  hasVoice?: boolean
}
export function AIChatBubble({ message, isUser, timestamp, hasVoice }: ChatBubbleProps) {
  return (
    <div className={cn("flex gap-2 max-w-[85%]", isUser ? "ml-auto flex-row-reverse" : "mr-auto")}>
      {!isUser && (
        <div className="h-8 w-8 rounded-full bg-primary flex items-center justify-center flex-shrink-0 mt-1">
          <svg viewBox="0 0 24 24" fill="none" className="h-4 w-4 stroke-white">
            <path d="M12 2l3.09 6.26L22 9.27l-5 4.87 1.18 6.88L12 17.77l-6.18 3.25L7 14.14 2 9.27l6.91-1.01L12 2z" strokeWidth="1.5" strokeLinecap="round" strokeLinejoin="round"/>
          </svg>
        </div>
      )}
      <div>
        <div className={cn(
          "rounded-2xl px-4 py-3 text-sm leading-relaxed",
          isUser
            ? "bg-primary text-primary-foreground rounded-tr-sm"
            : "bg-card text-foreground border border-border rounded-tl-sm"
        )}>
          {message}
        </div>
        <div className={cn("flex items-center gap-2 mt-1", isUser ? "justify-end" : "justify-start")}>
          {timestamp && <p className="text-xs text-muted-foreground">{timestamp}</p>}
          {!isUser && hasVoice && (
            <button className="flex items-center gap-1 text-xs text-primary">
              <Volume2 className="h-3 w-3" />
              Play
            </button>
          )}
        </div>
      </div>
    </div>
  )
}

// FarmerCard
interface FarmerCardProps {
  name: string
  location: string
  soilType: string
  landSize: string
}
export function FarmerCard({ name, location, soilType, landSize }: FarmerCardProps) {
  return (
    <div className="rounded-2xl bg-card border border-border p-4 flex items-center gap-4">
      <div className="h-14 w-14 rounded-full bg-primary/15 flex items-center justify-center text-primary font-bold text-xl font-heading flex-shrink-0">
        {name.charAt(0)}
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-foreground truncate font-heading">{name}</p>
        <p className="text-xs text-muted-foreground">{location}</p>
        <div className="flex gap-3 mt-1.5">
          <span className="text-xs bg-primary/10 text-primary rounded-full px-2 py-0.5">{soilType}</span>
          <span className="text-xs bg-accent/30 text-accent-foreground rounded-full px-2 py-0.5">{landSize} acres</span>
        </div>
      </div>
    </div>
  )
}
