"use client"

import { useState } from "react"
import { useApp } from "@/lib/app-context"
import { PageHeader } from "@/components/krishi/shared"
import { Phone, MessageSquare, Clock, Star, ChevronRight, CheckCircle2 } from "lucide-react"

interface Expert {
  id: string
  name: string
  title: string
  specialization: string
  experience: string
  rating: number
  reviews: number
  available: boolean
  languages: string[]
  center: string
}

const EXPERTS: Expert[] = [
  {
    id: "1",
    name: "Dr. Suresh Kumar",
    title: "Senior Agriculture Officer",
    specialization: "Soil Science & Crop Nutrition",
    experience: "15 years",
    rating: 4.8,
    reviews: 234,
    available: true,
    languages: ["Hindi", "Marathi", "English"],
    center: "Rythu Seva Kendra, Ahmednagar",
  },
  {
    id: "2",
    name: "Mrs. Priya Deshmukh",
    title: "Plant Protection Expert",
    specialization: "Pest Management & Disease Control",
    experience: "12 years",
    rating: 4.7,
    reviews: 189,
    available: true,
    languages: ["Marathi", "Hindi"],
    center: "KVK, Pune",
  },
  {
    id: "3",
    name: "Dr. Ramakrishna Rao",
    title: "Irrigation Specialist",
    specialization: "Water Management & Drip Irrigation",
    experience: "20 years",
    rating: 4.9,
    reviews: 312,
    available: false,
    languages: ["Telugu", "Kannada", "English"],
    center: "Rythu Seva Kendra, Hyderabad",
  },
]

const HELPLINES = [
  { name: "Kisan Call Centre", number: "1800-180-1551", free: true, hours: "24/7" },
  { name: "Rythu Seva Kendra", number: "1800-425-1422", free: true, hours: "9AM - 5PM" },
  { name: "Soil Testing Lab", number: "+91 20 2612 3456", free: false, hours: "Mon-Sat" },
]

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-0.5">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star
          key={s}
          className={`h-3 w-3 ${s <= Math.floor(rating) ? "text-amber-400 fill-amber-400" : "text-muted"}`}
        />
      ))}
      <span className="text-xs text-muted-foreground ml-1">{rating}</span>
    </div>
  )
}

function ExpertCard({ expert }: { expert: Expert }) {
  const [contacted, setContacted] = useState(false)

  return (
    <div className="rounded-2xl bg-card border border-border p-4">
      <div className="flex items-start gap-3 mb-3">
        <div className="h-12 w-12 rounded-full bg-primary/15 flex items-center justify-center text-primary font-bold text-base flex-shrink-0 font-heading">
          {expert.name.split(" ").map((n) => n[0]).join("").slice(0, 2)}
        </div>
        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2">
            <p className="text-sm font-bold text-foreground font-heading">{expert.name}</p>
            <div className={`h-2 w-2 rounded-full flex-shrink-0 ${expert.available ? "bg-primary" : "bg-muted-foreground"}`} />
          </div>
          <p className="text-xs text-muted-foreground">{expert.title}</p>
          <StarRating rating={expert.rating} />
        </div>
        <span className={`text-xs font-semibold rounded-full px-2 py-1 flex-shrink-0 ${expert.available ? "bg-primary/10 text-primary" : "bg-muted text-muted-foreground"}`}>
          {expert.available ? "Available" : "Busy"}
        </span>
      </div>

      <div className="space-y-1.5 mb-4">
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span className="font-medium text-foreground">Specialization:</span>
          {expert.specialization}
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span className="font-medium text-foreground">Experience:</span>
          {expert.experience}
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span className="font-medium text-foreground">Languages:</span>
          {expert.languages.join(", ")}
        </div>
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span className="font-medium text-foreground">Center:</span>
          {expert.center}
        </div>
      </div>

      {contacted ? (
        <div className="flex items-center gap-2 rounded-xl bg-primary/10 px-4 py-3">
          <CheckCircle2 className="h-4 w-4 text-primary" />
          <p className="text-sm font-medium text-primary">Request sent! Expert will call within 30 min.</p>
        </div>
      ) : (
        <div className="grid grid-cols-2 gap-2">
          <button
            onClick={() => setContacted(true)}
            disabled={!expert.available}
            className="flex items-center justify-center gap-2 rounded-xl bg-primary py-2.5 text-xs font-semibold text-primary-foreground hover:bg-primary/90 disabled:opacity-40 disabled:cursor-not-allowed transition-all"
          >
            <Phone className="h-3.5 w-3.5" />
            Call Now
          </button>
          <button
            onClick={() => setContacted(true)}
            className="flex items-center justify-center gap-2 rounded-xl border border-primary bg-transparent py-2.5 text-xs font-semibold text-primary hover:bg-primary/5 transition-all"
          >
            <MessageSquare className="h-3.5 w-3.5" />
            Message
          </button>
        </div>
      )}
    </div>
  )
}

export function ExpertScreen() {
  const { setScreen, t } = useApp()

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <PageHeader
        title={t("expertTitle")}
        subtitle="Free agriculture advisory services"
        onBack={() => setScreen("dashboard")}
      />

      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-5 pb-8">
        {/* Hero */}
        <div className="rounded-2xl bg-primary p-5 text-center">
          <div className="h-14 w-14 rounded-full bg-white/20 flex items-center justify-center mx-auto mb-3">
            <Phone className="h-7 w-7 text-white" />
          </div>
          <p className="text-lg font-bold text-white font-heading mb-1">{t("contactCenter")}</p>
          <p className="text-sm text-white/70 mb-4">Get free expert advice from government agriculture officers</p>
          <a
            href="tel:18001801551"
            className="inline-flex items-center gap-2 rounded-2xl bg-white px-6 py-3 text-sm font-bold text-primary hover:bg-white/90 transition-all"
          >
            <Phone className="h-4 w-4" />
            1800-180-1551 (Free)
          </a>
        </div>

        {/* Helplines */}
        <div className="rounded-2xl bg-card border border-border p-4">
          <h2 className="text-sm font-bold text-foreground mb-3">Helplines</h2>
          <div className="space-y-3">
            {HELPLINES.map((h) => (
              <div key={h.name} className="flex items-center justify-between">
                <div className="flex items-center gap-3">
                  <div className="h-9 w-9 rounded-full bg-primary/10 flex items-center justify-center">
                    <Phone className="h-4 w-4 text-primary" />
                  </div>
                  <div>
                    <p className="text-sm font-semibold text-foreground">{h.name}</p>
                    <div className="flex items-center gap-2 text-xs text-muted-foreground">
                      <Clock className="h-3 w-3" />
                      {h.hours}
                      {h.free && <span className="rounded-full bg-primary/10 text-primary px-1.5 py-0.5 font-medium">Free</span>}
                    </div>
                  </div>
                </div>
                <a href={`tel:${h.number.replace(/[^0-9+]/g, "")}`} className="text-sm font-bold text-primary">
                  {h.number}
                </a>
              </div>
            ))}
          </div>
        </div>

        {/* Expert list */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-foreground">Agriculture Experts</h2>
            <span className="text-xs text-muted-foreground">{EXPERTS.filter((e) => e.available).length} available now</span>
          </div>
          <div className="space-y-3">
            {EXPERTS.map((expert) => (
              <ExpertCard key={expert.id} expert={expert} />
            ))}
          </div>
        </div>

        {/* Schedule appointment */}
        <div className="rounded-2xl bg-card border border-border p-4">
          <h2 className="text-sm font-bold text-foreground mb-3">Schedule Farm Visit</h2>
          <p className="text-xs text-muted-foreground mb-4">Request an agriculture officer to visit your farm for on-site consultation. Free service under government scheme.</p>
          <button className="w-full flex items-center justify-between rounded-xl bg-muted px-4 py-3.5 hover:bg-muted/70 transition-colors">
            <div className="flex items-center gap-3">
              <div className="h-8 w-8 rounded-full bg-accent/30 flex items-center justify-center">
                <Clock className="h-4 w-4 text-accent-foreground" />
              </div>
              <div className="text-left">
                <p className="text-sm font-semibold text-foreground">Book Farm Visit</p>
                <p className="text-xs text-muted-foreground">Usually within 3-5 working days</p>
              </div>
            </div>
            <ChevronRight className="h-4 w-4 text-muted-foreground" />
          </button>
        </div>
      </div>
    </div>
  )
}
