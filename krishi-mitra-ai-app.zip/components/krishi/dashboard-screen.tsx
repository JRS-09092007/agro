"use client"

import { useApp, type Screen } from "@/lib/app-context"
import { OfflineIndicator, WeatherCard, FarmerCard, LanguageSwitcher } from "@/components/krishi/shared"
import {
  Cloud, Sprout, Droplets, ScanLine, Bot, Phone, Wifi,
  ChevronRight, Bell, Settings
} from "lucide-react"

interface DashboardCardProps {
  title: string
  subtitle: string
  icon: React.ReactNode
  color: string
  bgColor: string
  onClick: () => void
  badge?: string
}

function DashboardCard({ title, subtitle, icon, color, bgColor, onClick, badge }: DashboardCardProps) {
  return (
    <button
      onClick={onClick}
      className="relative flex items-center gap-4 rounded-2xl bg-card border border-border p-4 text-left w-full hover:shadow-md active:scale-98 transition-all duration-150"
    >
      <div className={`h-12 w-12 rounded-2xl flex items-center justify-center flex-shrink-0 ${bgColor}`}>
        <span className={color}>{icon}</span>
      </div>
      <div className="flex-1 min-w-0">
        <p className="font-semibold text-foreground font-heading text-sm">{title}</p>
        <p className="text-xs text-muted-foreground mt-0.5 leading-relaxed">{subtitle}</p>
      </div>
      {badge && (
        <span className="absolute top-3 right-3 rounded-full bg-destructive px-1.5 py-0.5 text-xs font-bold text-white">
          {badge}
        </span>
      )}
      <ChevronRight className="h-4 w-4 text-muted-foreground flex-shrink-0" />
    </button>
  )
}

export function DashboardScreen() {
  const { setScreen, farmer, t, isOnline } = useApp()

  const nav = (screen: Screen) => () => setScreen(screen)

  const today = new Date().toLocaleDateString("en-IN", {
    weekday: "long", day: "numeric", month: "long"
  })

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <header className="bg-primary px-4 pt-10 pb-5">
        <div className="flex items-start justify-between mb-4">
          <div>
            <p className="text-sm text-white/70">{today}</p>
            <h1 className="text-xl font-extrabold text-white font-heading mt-0.5">
              {t("goodMorning")}, {farmer.name.split(" ")[0]}
            </h1>
            <p className="text-xs text-white/60 mt-0.5">{farmer.village}, {farmer.district}</p>
          </div>
          <div className="flex items-center gap-2">
            <LanguageSwitcher variant="icon" />
            <button className="h-9 w-9 rounded-full bg-white/15 flex items-center justify-center">
              <Bell className="h-4 w-4 text-white" />
            </button>
            <button
              onClick={() => setScreen("registration")}
              className="h-9 w-9 rounded-full bg-white/15 flex items-center justify-center"
            >
              <Settings className="h-4 w-4 text-white" />
            </button>
          </div>
        </div>
        <OfflineIndicator />
      </header>

      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-5 pb-6">
        {/* Offline mode banner */}
        {!isOnline && (
          <div className="rounded-2xl bg-amber-50 border border-amber-200 p-4 flex items-center gap-3">
            <Wifi className="h-5 w-5 text-amber-600 flex-shrink-0" />
            <div>
              <p className="text-sm font-semibold text-amber-800">{t("offlineMode")}</p>
              <p className="text-xs text-amber-600">{t("offlineDesc")}</p>
            </div>
          </div>
        )}

        {/* Farmer profile card */}
        <FarmerCard
          name={farmer.name}
          location={`${farmer.village}, ${farmer.district}, ${farmer.state}`}
          soilType={farmer.soilType}
          landSize={farmer.landSize}
        />

        {/* Weather widget */}
        <div>
          <div className="flex items-center justify-between mb-2">
            <h2 className="text-sm font-bold text-foreground">{t("weatherToday")}</h2>
            <button onClick={nav("weather")} className="text-xs text-primary font-medium">View Alerts</button>
          </div>
          <WeatherCard
            temp="32°C"
            condition="Partly Cloudy"
            location={`${farmer.village}, ${farmer.state}`}
            humidity="68%"
            wind="12 km/h"
          />
        </div>

        {/* Main features */}
        <div>
          <h2 className="text-sm font-bold text-foreground mb-3">Quick Actions</h2>
          <div className="space-y-3">
            <DashboardCard
              title={t("aiAssistant")}
              subtitle="Ask any farming question in your language"
              icon={<Bot className="h-6 w-6" />}
              color="text-primary"
              bgColor="bg-primary/10"
              onClick={nav("chat")}
              badge="New"
            />
            <DashboardCard
              title={t("cropRecommendation")}
              subtitle="AI suggests best crop for your soil & season"
              icon={<Sprout className="h-6 w-6" />}
              color="text-emerald-600"
              bgColor="bg-emerald-50"
              onClick={nav("crop")}
            />
            <DashboardCard
              title={t("waterAdvisory")}
              subtitle="Smart irrigation schedule & water saving tips"
              icon={<Droplets className="h-6 w-6" />}
              color="text-sky"
              bgColor="bg-sky/10"
              onClick={nav("water")}
            />
            <DashboardCard
              title={t("diseaseScanner")}
              subtitle="Upload crop photo for instant disease detection"
              icon={<ScanLine className="h-6 w-6" />}
              color="text-amber-600"
              bgColor="bg-amber-50"
              onClick={nav("disease")}
            />
          </div>
        </div>

        {/* More options */}
        <div>
          <h2 className="text-sm font-bold text-foreground mb-3">More Services</h2>
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={nav("weather")}
              className="rounded-2xl bg-card border border-border p-4 text-left hover:shadow-md transition-all"
            >
              <Cloud className="h-5 w-5 text-sky mb-2" />
              <p className="text-sm font-semibold text-foreground font-heading">Weather Alerts</p>
              <p className="text-xs text-muted-foreground mt-0.5">Rain & storm warnings</p>
            </button>
            <button
              onClick={nav("offline")}
              className="rounded-2xl bg-card border border-border p-4 text-left hover:shadow-md transition-all"
            >
              <Wifi className="h-5 w-5 text-primary mb-2" />
              <p className="text-sm font-semibold text-foreground font-heading">Offline Mode</p>
              <p className="text-xs text-muted-foreground mt-0.5">Works without internet</p>
            </button>
            <button
              onClick={nav("expert")}
              className="rounded-2xl bg-card border border-border p-4 text-left hover:shadow-md transition-all col-span-2"
            >
              <div className="flex items-center gap-3">
                <Phone className="h-5 w-5 text-earth" />
                <div>
                  <p className="text-sm font-semibold text-foreground font-heading">{t("expertTitle")}</p>
                  <p className="text-xs text-muted-foreground">Talk to agriculture experts</p>
                </div>
              </div>
            </button>
          </div>
        </div>

        {/* AI capabilities banner */}
        <div className="rounded-2xl bg-primary p-4">
          <p className="text-xs font-bold text-white/70 uppercase tracking-wider mb-2">{t("poweredBy")}</p>
          <div className="grid grid-cols-2 gap-1.5">
            {["Crop Recommendation", "Image Diagnosis", "Weather Analysis", "Voice Assistance"].map((f) => (
              <div key={f} className="flex items-center gap-2">
                <div className="h-1.5 w-1.5 rounded-full bg-accent flex-shrink-0" />
                <p className="text-xs text-white/90">{f}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
