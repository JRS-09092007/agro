"use client"

import { useApp } from "@/lib/app-context"
import { PageHeader } from "@/components/krishi/shared"
import { Droplets, Cloud, TrendingDown, AlertTriangle, CheckCircle2, Info } from "lucide-react"

interface ForecastDay {
  day: string
  icon: string
  high: number
  low: number
  rain: number
}

const FORECAST: ForecastDay[] = [
  { day: "Today", icon: "partly-cloudy", high: 32, low: 23, rain: 20 },
  { day: "Tomorrow", icon: "rainy", high: 27, low: 21, rain: 80 },
  { day: "Wed", icon: "rainy", high: 25, low: 20, rain: 65 },
  { day: "Thu", icon: "cloudy", high: 28, low: 22, rain: 30 },
  { day: "Fri", icon: "sunny", high: 33, low: 24, rain: 5 },
]

function WeatherIcon({ type }: { type: string }) {
  const icons: Record<string, React.ReactNode> = {
    sunny: (
      <svg viewBox="0 0 24 24" fill="none" className="h-8 w-8">
        <circle cx="12" cy="12" r="4" fill="#FCD34D"/>
        {[0,45,90,135,180,225,270,315].map((deg) => (
          <line key={deg} x1="12" y1="4" x2="12" y2="2" stroke="#FCD34D" strokeWidth="2" strokeLinecap="round"
            transform={`rotate(${deg}, 12, 12)`}/>
        ))}
      </svg>
    ),
    rainy: (
      <svg viewBox="0 0 24 24" fill="none" className="h-8 w-8">
        <path d="M6 16c-2.2 0-4-1.8-4-4 0-1.9 1.3-3.5 3.1-3.9C5.4 6.3 7 5 9 5c2.2 0 4.1 1.4 4.8 3.5.1 0 .1 0 .2 0 1.7 0 3 1.3 3 3s-1.3 3-3 3H6z" fill="#94A3B8"/>
        <path d="M8 19l-1 2M12 19l-1 2M16 19l-1 2" stroke="#60A5FA" strokeWidth="1.5" strokeLinecap="round"/>
      </svg>
    ),
    cloudy: (
      <svg viewBox="0 0 24 24" fill="none" className="h-8 w-8">
        <path d="M6 16c-2.2 0-4-1.8-4-4 0-1.9 1.3-3.5 3.1-3.9C5.4 6.3 7 5 9 5c2.2 0 4.1 1.4 4.8 3.5.1 0 .1 0 .2 0 1.7 0 3 1.3 3 3s-1.3 3-3 3H6z" fill="#94A3B8"/>
      </svg>
    ),
    "partly-cloudy": (
      <svg viewBox="0 0 24 24" fill="none" className="h-8 w-8">
        <circle cx="8" cy="10" r="3" fill="#FCD34D"/>
        <path d="M9 16c-2.2 0-4-1.5-4-3.5S7 9 9 9c.3 0 .6 0 .9.1C10.5 7.8 12 7 13.5 7c2.5 0 4.5 2 4.5 4.5S16 16 13.5 16H9z" fill="#CBD5E1"/>
      </svg>
    ),
  }
  return <>{icons[type] ?? icons.sunny}</>
}

function MoistureBar({ value }: { value: number }) {
  const color = value < 30 ? "bg-destructive" : value < 50 ? "bg-amber-400" : "bg-primary"
  return (
    <div className="space-y-2">
      <div className="flex items-center justify-between text-sm">
        <span className="font-medium text-foreground">Soil Moisture</span>
        <span className={`font-bold ${value < 30 ? "text-destructive" : value < 50 ? "text-amber-500" : "text-primary"}`}>{value}%</span>
      </div>
      <div className="h-3 rounded-full bg-muted overflow-hidden">
        <div className={`h-full rounded-full transition-all duration-700 ${color}`} style={{ width: `${value}%` }} />
      </div>
      <div className="flex justify-between text-xs text-muted-foreground">
        <span>Dry (0%)</span>
        <span>Optimal (60%)</span>
        <span>Wet (100%)</span>
      </div>
    </div>
  )
}

export function WaterScreen() {
  const { setScreen, farmer, t } = useApp()

  const soilMoisture = 47

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <PageHeader
        title={t("waterTitle")}
        subtitle="Smart irrigation planning"
        onBack={() => setScreen("dashboard")}
      />

      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-5 pb-8">
        {/* Primary advisory card */}
        <div className="rounded-2xl bg-primary p-5">
          <div className="flex items-start justify-between mb-3">
            <div>
              <p className="text-xs text-white/70 font-medium uppercase tracking-wide">Today&apos;s Advisory</p>
              <p className="text-lg font-bold text-white font-heading mt-1">Do not irrigate today</p>
            </div>
            <div className="h-10 w-10 rounded-full bg-white/20 flex items-center justify-center">
              <CheckCircle2 className="h-5 w-5 text-white" />
            </div>
          </div>
          <p className="text-sm text-white/80 leading-relaxed">
            Rain expected tomorrow (80% probability). Save water and let natural rainfall replenish your soil.
          </p>
          <div className="mt-3 flex items-center gap-2">
            <TrendingDown className="h-4 w-4 text-white/60" />
            <span className="text-xs text-white/60">Saves approx. 1,200 litres per acre</span>
          </div>
        </div>

        {/* Soil moisture */}
        <div className="rounded-2xl bg-card border border-border p-4">
          <div className="flex items-center gap-2 mb-4">
            <Droplets className="h-5 w-5 text-sky" />
            <h2 className="text-sm font-bold text-foreground">{t("soilMoisture")}</h2>
          </div>
          <MoistureBar value={soilMoisture} />
          <div className="mt-3 rounded-xl bg-amber-50 border border-amber-100 p-3 flex items-start gap-2">
            <Info className="h-4 w-4 text-amber-500 flex-shrink-0 mt-0.5" />
            <p className="text-xs text-amber-700">Moisture is adequate but slightly below optimal. Post-rain levels should reach 65-70%.</p>
          </div>
        </div>

        {/* 5-day forecast */}
        <div className="rounded-2xl bg-card border border-border p-4">
          <div className="flex items-center gap-2 mb-4">
            <Cloud className="h-5 w-5 text-sky" />
            <h2 className="text-sm font-bold text-foreground">{t("forecast")}</h2>
          </div>
          <div className="grid grid-cols-5 gap-1">
            {FORECAST.map((day) => (
              <div key={day.day} className={`rounded-xl p-2 text-center ${day.day === "Today" ? "bg-primary/10 border border-primary/20" : ""}`}>
                <p className="text-xs font-medium text-muted-foreground mb-1">{day.day}</p>
                <WeatherIcon type={day.icon} />
                <p className="text-xs font-bold text-foreground mt-1">{day.high}°</p>
                <p className="text-xs text-muted-foreground">{day.low}°</p>
                <div className="mt-1 flex items-center justify-center gap-0.5">
                  <Droplets className="h-2.5 w-2.5 text-sky" />
                  <span className="text-xs text-sky font-medium">{day.rain}%</span>
                </div>
              </div>
            ))}
          </div>
        </div>

        {/* Irrigation schedule */}
        <div className="rounded-2xl bg-card border border-border p-4 space-y-3">
          <h2 className="text-sm font-bold text-foreground">{t("irrigationRec")}</h2>
          {[
            { day: "Today", action: "Skip irrigation", reason: "Rain expected tomorrow", icon: CheckCircle2, color: "text-primary", bg: "bg-primary/10" },
            { day: "Tomorrow", action: "Rainfall expected", reason: "Heavy rain 80% - Natural irrigation", icon: Cloud, color: "text-sky", bg: "bg-sky/10" },
            { day: "Thursday", action: "Irrigate if needed", reason: "Check soil moisture first", icon: Droplets, color: "text-amber-500", bg: "bg-amber-50" },
            { day: "Friday", action: "Full irrigation", reason: "No rain, hot & dry conditions", icon: AlertTriangle, color: "text-destructive", bg: "bg-destructive/10" },
          ].map((item) => (
            <div key={item.day} className={`flex items-center gap-3 rounded-xl ${item.bg} p-3`}>
              <div className={`h-8 w-8 rounded-full flex items-center justify-center flex-shrink-0 ${item.bg}`}>
                <item.icon className={`h-4 w-4 ${item.color}`} />
              </div>
              <div className="flex-1 min-w-0">
                <p className="text-xs font-bold text-foreground">{item.day}: {item.action}</p>
                <p className="text-xs text-muted-foreground">{item.reason}</p>
              </div>
            </div>
          ))}
        </div>

        {/* Water saving tips */}
        <div className="rounded-2xl bg-card border border-border p-4">
          <h2 className="text-sm font-bold text-foreground mb-3">Water Saving Tips</h2>
          <div className="space-y-2">
            {[
              "Use drip irrigation to save 40-50% water",
              "Mulch soil to reduce evaporation by 25%",
              "Irrigate early morning or evening",
              `With ${farmer.soilType}, check 6-inch depth before irrigating`,
            ].map((tip, i) => (
              <div key={i} className="flex items-start gap-2">
                <div className="h-1.5 w-1.5 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                <p className="text-xs text-muted-foreground leading-relaxed">{tip}</p>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
