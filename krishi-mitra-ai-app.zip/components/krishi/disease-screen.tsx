"use client"

import { useState, useRef } from "react"
import { useApp } from "@/lib/app-context"
import { DiseaseResultCard, PageHeader } from "@/components/krishi/shared"
import { Camera, Upload, ScanLine, Loader2, RefreshCw, Info } from "lucide-react"

interface DiseaseResult {
  disease: string
  confidence: number
  treatment: string[]
  severity: "low" | "medium" | "high"
  cropAffected: string
  spread: string
}

const DISEASE_RESULTS: DiseaseResult[] = [
  {
    disease: "Leaf Blight",
    confidence: 92,
    treatment: [
      "Remove and destroy all infected leaves immediately",
      "Apply Mancozeb (2g/L) or Copper Oxychloride spray",
      "Avoid overhead irrigation; use drip instead",
      "Maintain proper plant spacing for air circulation",
    ],
    severity: "high",
    cropAffected: "Soybean",
    spread: "High - spreads via wind and water",
  },
  {
    disease: "Yellow Mosaic Virus",
    confidence: 78,
    treatment: [
      "Uproot and bury infected plants to prevent spread",
      "Control whitefly vectors with Imidacloprid spray",
      "Plant resistant varieties in next season",
      "Use yellow sticky traps to monitor whitefly population",
    ],
    severity: "medium",
    cropAffected: "Soybean",
    spread: "Medium - spreads via whitefly vectors",
  },
]

type Stage = "upload" | "analyzing" | "result"

export function DiseaseScreen() {
  const { setScreen, t } = useApp()
  const [stage, setStage] = useState<Stage>("upload")
  const [imageUrl, setImageUrl] = useState<string | null>(null)
  const [resultIndex, setResultIndex] = useState(0)
  const fileRef = useRef<HTMLInputElement>(null)

  const handleFileSelect = (file: File) => {
    const url = URL.createObjectURL(file)
    setImageUrl(url)
    setStage("analyzing")
    setTimeout(() => {
      setStage("result")
    }, 2500)
  }

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (file) handleFileSelect(file)
  }

  const reset = () => {
    setStage("upload")
    setImageUrl(null)
    setResultIndex(0)
  }

  const result = DISEASE_RESULTS[resultIndex]

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <PageHeader
        title={t("diseaseTitle")}
        subtitle="AI-powered crop diagnosis"
        onBack={() => setScreen("dashboard")}
        rightElement={
          stage === "result" ? (
            <button onClick={reset} className="flex items-center gap-1.5 text-xs font-medium text-primary">
              <RefreshCw className="h-3.5 w-3.5" />
              New Scan
            </button>
          ) : undefined
        }
      />

      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-5 pb-8">
        {stage === "upload" && (
          <>
            {/* Instructions */}
            <div className="rounded-2xl bg-primary/5 border border-primary/10 p-4 flex items-start gap-3">
              <Info className="h-5 w-5 text-primary flex-shrink-0 mt-0.5" />
              <div>
                <p className="text-sm font-semibold text-foreground mb-1">How to get best results</p>
                <ul className="space-y-1">
                  {["Take a clear close-up photo of affected leaves", "Ensure good lighting, avoid shadows", "Include both healthy and affected parts"].map((tip) => (
                    <li key={tip} className="text-xs text-muted-foreground flex items-start gap-1.5">
                      <span className="h-1 w-1 rounded-full bg-primary mt-1.5 flex-shrink-0" />
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
            </div>

            {/* Upload area */}
            <div
              className="rounded-2xl border-2 border-dashed border-primary/30 bg-primary/5 p-8 text-center cursor-pointer hover:border-primary/50 hover:bg-primary/10 transition-all"
              onClick={() => fileRef.current?.click()}
            >
              <div className="h-16 w-16 rounded-full bg-primary/15 flex items-center justify-center mx-auto mb-4">
                <Upload className="h-8 w-8 text-primary" />
              </div>
              <p className="text-base font-semibold text-foreground font-heading mb-1">{t("uploadImage")}</p>
              <p className="text-xs text-muted-foreground">Tap to select from gallery</p>
              <input ref={fileRef} type="file" accept="image/*" className="hidden" onChange={handleChange} />
            </div>

            {/* Camera button */}
            <button
              onClick={() => fileRef.current?.click()}
              className="w-full flex items-center justify-center gap-3 rounded-2xl bg-card border border-border py-4 text-sm font-semibold text-foreground hover:bg-muted transition-all"
            >
              <div className="h-10 w-10 rounded-full bg-amber-50 flex items-center justify-center">
                <Camera className="h-5 w-5 text-amber-600" />
              </div>
              {t("takePhoto")}
            </button>

            {/* Common diseases */}
            <div className="rounded-2xl bg-card border border-border p-4">
              <h2 className="text-sm font-bold text-foreground mb-3">Common Diseases in Maharashtra</h2>
              <div className="space-y-2">
                {[
                  { name: "Leaf Blight", crop: "Soybean, Cotton", severity: "High" },
                  { name: "Yellow Mosaic", crop: "Soybean, Mung Bean", severity: "Medium" },
                  { name: "Root Rot", crop: "All Crops", severity: "High" },
                  { name: "Powdery Mildew", crop: "Wheat, Onion", severity: "Low" },
                ].map((d) => (
                  <div key={d.name} className="flex items-center justify-between py-1.5 border-b border-border last:border-0">
                    <div>
                      <p className="text-sm font-medium text-foreground">{d.name}</p>
                      <p className="text-xs text-muted-foreground">{d.crop}</p>
                    </div>
                    <span className={`text-xs font-semibold rounded-full px-2 py-0.5 ${
                      d.severity === "High" ? "bg-destructive/10 text-destructive" :
                      d.severity === "Medium" ? "bg-amber-50 text-amber-600" :
                      "bg-primary/10 text-primary"
                    }`}>{d.severity}</span>
                  </div>
                ))}
              </div>
            </div>
          </>
        )}

        {stage === "analyzing" && (
          <div className="flex flex-col items-center justify-center py-16 space-y-6">
            {imageUrl && (
              <div className="relative">
                <img src={imageUrl} alt="Crop" className="h-48 w-48 rounded-2xl object-cover border-4 border-primary/30" />
                <div className="absolute inset-0 rounded-2xl border-4 border-primary animate-pulse" />
              </div>
            )}
            <div className="text-center space-y-3">
              <div className="flex items-center justify-center gap-2">
                <Loader2 className="h-5 w-5 text-primary animate-spin" />
                <p className="text-base font-semibold text-foreground font-heading">Analyzing with Gemini AI...</p>
              </div>
              <p className="text-sm text-muted-foreground">Checking for diseases, pests, and deficiencies</p>
              <div className="flex gap-2 justify-center">
                {["Scanning leaf patterns", "Checking color distribution", "Identifying pathogens"].map((step) => (
                  <span key={step} className="rounded-full bg-primary/10 px-2 py-1 text-xs text-primary font-medium">{step}</span>
                ))}
              </div>
            </div>
          </div>
        )}

        {stage === "result" && result && (
          <div className="space-y-4">
            {/* Analyzed image */}
            {imageUrl && (
              <div className="relative rounded-2xl overflow-hidden">
                <img src={imageUrl} alt="Analyzed crop" className="w-full h-40 object-cover" />
                <div className="absolute inset-0 bg-foreground/20" />
                <div className="absolute top-3 left-3 flex items-center gap-1.5 rounded-full bg-foreground/50 backdrop-blur-sm px-3 py-1.5">
                  <ScanLine className="h-3.5 w-3.5 text-white" />
                  <span className="text-xs font-medium text-white">Analysis Complete</span>
                </div>
              </div>
            )}

            {/* Result card */}
            <DiseaseResultCard
              disease={result.disease}
              confidence={result.confidence}
              treatment={result.treatment}
              severity={result.severity}
            />

            {/* Additional info */}
            <div className="rounded-2xl bg-card border border-border p-4 space-y-3">
              <h3 className="text-sm font-bold text-foreground">Additional Information</h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="rounded-xl bg-muted p-3">
                  <p className="text-xs text-muted-foreground">Crop Affected</p>
                  <p className="text-sm font-semibold text-foreground">{result.cropAffected}</p>
                </div>
                <div className="rounded-xl bg-muted p-3">
                  <p className="text-xs text-muted-foreground">Spread Risk</p>
                  <p className="text-sm font-semibold text-foreground">{result.spread.split(" - ")[0]}</p>
                </div>
              </div>
              <div className="rounded-xl bg-muted p-3">
                <p className="text-xs text-muted-foreground mb-1">Spread Pattern</p>
                <p className="text-xs text-foreground">{result.spread}</p>
              </div>
            </div>

            {/* Other possible diseases */}
            <div className="rounded-2xl bg-card border border-border p-4">
              <p className="text-sm font-bold text-foreground mb-3">Other Possible Conditions</p>
              <button
                onClick={() => setResultIndex(1 - resultIndex)}
                className="w-full flex items-center justify-between rounded-xl bg-muted p-3 hover:bg-muted/70 transition-colors"
              >
                <div>
                  <p className="text-sm font-medium text-foreground">{DISEASE_RESULTS[1 - resultIndex].disease}</p>
                  <p className="text-xs text-muted-foreground">{DISEASE_RESULTS[1 - resultIndex].confidence}% confidence</p>
                </div>
                <span className="text-xs font-medium text-primary">View</span>
              </button>
            </div>

            {/* Expert advice */}
            <button
              onClick={() => setScreen("expert")}
              className="w-full rounded-2xl bg-primary py-4 text-sm font-bold text-primary-foreground font-heading hover:bg-primary/90 transition-all"
            >
              Get Expert Advice
            </button>
          </div>
        )}
      </div>
    </div>
  )
}
