"use client"

import { useState } from "react"
import { useApp, LANGUAGES, SOIL_TYPES, WATER_AVAILABILITY, type FarmerProfile, type Language } from "@/lib/app-context"
import { VoiceButton } from "@/components/krishi/shared"
import { ChevronDown, User, Phone, MapPin, Landmark, Globe, Maximize2, Droplets } from "lucide-react"

interface FieldProps {
  label: string
  value: string
  onChange: (v: string) => void
  placeholder?: string
  type?: string
  icon: React.ReactNode
  voiceEnabled?: boolean
}

function Field({ label, value, onChange, placeholder, type = "text", icon, voiceEnabled = true }: FieldProps) {
  return (
    <div>
      <label className="block text-sm font-semibold text-foreground mb-1.5">{label}</label>
      <div className="flex items-center gap-2">
        <div className="relative flex-1">
          <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">{icon}</div>
          <input
            type={type}
            value={value}
            onChange={(e) => onChange(e.target.value)}
            placeholder={placeholder}
            className="w-full rounded-xl border border-input bg-card pl-10 pr-4 py-3.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 transition-all"
          />
        </div>
        {voiceEnabled && <VoiceButton size="sm" />}
      </div>
    </div>
  )
}

interface SelectFieldProps {
  label: string
  value: string
  options: string[]
  onChange: (v: string) => void
  icon: React.ReactNode
}

function SelectField({ label, value, options, onChange, icon }: SelectFieldProps) {
  return (
    <div>
      <label className="block text-sm font-semibold text-foreground mb-1.5">{label}</label>
      <div className="relative">
        <div className="absolute left-3 top-1/2 -translate-y-1/2 text-muted-foreground">{icon}</div>
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full appearance-none rounded-xl border border-input bg-card pl-10 pr-10 py-3.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 transition-all"
        >
          <option value="">Select...</option>
          {options.map((o) => (
            <option key={o} value={o}>{o}</option>
          ))}
        </select>
        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
      </div>
    </div>
  )
}

export function RegistrationScreen() {
  const { setScreen, setFarmer, farmer, t } = useApp()
  const [form, setForm] = useState<FarmerProfile>({ ...farmer })

  const update = (key: keyof FarmerProfile) => (val: string) => setForm((f) => ({ ...f, [key]: val }))

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    setFarmer(form)
    setScreen("dashboard")
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      {/* Header */}
      <div className="bg-primary px-4 pb-6 pt-10">
        <button
          onClick={() => setScreen("splash")}
          className="mb-4 text-xs font-medium text-white/70 hover:text-white flex items-center gap-1"
        >
          <ChevronDown className="h-3 w-3 rotate-90" /> Back
        </button>
        <h1 className="text-xl font-extrabold text-white font-heading">{t("registration")}</h1>
        <p className="text-sm text-white/70 mt-1">Tell us about yourself to get personalized advice</p>
      </div>

      <form onSubmit={handleSubmit} className="flex-1 overflow-y-auto">
        <div className="px-4 py-5 space-y-4 pb-32">
          {/* Personal Info */}
          <div className="rounded-2xl bg-card border border-border p-4 space-y-4">
            <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Personal Information</h2>
            <Field
              label={t("name")}
              value={form.name}
              onChange={update("name")}
              placeholder="e.g. Ramesh Patil"
              icon={<User className="h-4 w-4" />}
            />
            <Field
              label={t("phone")}
              value={form.phone}
              onChange={update("phone")}
              placeholder="+91 98765 43210"
              type="tel"
              icon={<Phone className="h-4 w-4" />}
            />
          </div>

          {/* Location */}
          <div className="rounded-2xl bg-card border border-border p-4 space-y-4">
            <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Location</h2>
            <Field
              label={t("village")}
              value={form.village}
              onChange={update("village")}
              placeholder="e.g. Shirdi"
              icon={<MapPin className="h-4 w-4" />}
            />
            <Field
              label={t("district")}
              value={form.district}
              onChange={update("district")}
              placeholder="e.g. Ahmednagar"
              icon={<Landmark className="h-4 w-4" />}
            />
            <Field
              label={t("state")}
              value={form.state}
              onChange={update("state")}
              placeholder="e.g. Maharashtra"
              icon={<Globe className="h-4 w-4" />}
            />
          </div>

          {/* Farm Details */}
          <div className="rounded-2xl bg-card border border-border p-4 space-y-4">
            <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider">Farm Details</h2>
            <Field
              label={t("landSize")}
              value={form.landSize}
              onChange={update("landSize")}
              placeholder="e.g. 3.5"
              type="number"
              icon={<Maximize2 className="h-4 w-4" />}
            />
            <SelectField
              label={t("soilType")}
              value={form.soilType}
              options={SOIL_TYPES}
              onChange={update("soilType")}
              icon={<Globe className="h-4 w-4" />}
            />
            <SelectField
              label={t("waterAvailability")}
              value={form.waterAvailability}
              options={WATER_AVAILABILITY}
              onChange={update("waterAvailability")}
              icon={<Droplets className="h-4 w-4" />}
            />
          </div>

          {/* Language */}
          <div className="rounded-2xl bg-card border border-border p-4">
            <h2 className="text-xs font-bold text-muted-foreground uppercase tracking-wider mb-3">Preferred Language</h2>
            <div className="grid grid-cols-2 gap-2">
              {LANGUAGES.map((lang) => (
                <button
                  key={lang.code}
                  type="button"
                  onClick={() => update("language")(lang.code)}
                  className={`rounded-xl border-2 py-2.5 px-3 text-sm font-medium transition-all ${
                    form.language === lang.code
                      ? "border-primary bg-primary/10 text-primary"
                      : "border-border bg-background text-foreground hover:border-primary/40"
                  }`}
                >
                  <span className="block font-semibold">{lang.native}</span>
                  <span className="block text-xs text-muted-foreground">{lang.label}</span>
                </button>
              ))}
            </div>
          </div>
        </div>

        {/* Fixed submit button */}
        <div className="fixed bottom-0 left-0 right-0 bg-card border-t border-border p-4 max-w-md mx-auto">
          <button
            type="submit"
            className="w-full rounded-2xl bg-primary py-4 text-base font-bold text-primary-foreground shadow-lg hover:bg-primary/90 active:scale-98 transition-all font-heading"
          >
            {t("register")} →
          </button>
        </div>
      </form>
    </div>
  )
}
