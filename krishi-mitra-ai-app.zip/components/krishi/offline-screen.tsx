"use client"

import { useState } from "react"
import { useApp } from "@/lib/app-context"
import { PageHeader } from "@/components/krishi/shared"
import { WifiOff, RefreshCw, Database, Sprout, Bug, Lightbulb, CheckCircle2, Clock, Loader2 } from "lucide-react"

interface OfflineResource {
  icon: React.ReactNode
  title: string
  items: string
  lastSync: string
  available: boolean
}

const OFFLINE_RESOURCES: OfflineResource[] = [
  { icon: <Sprout className="h-5 w-5 text-primary" />, title: "Crop Information", items: "250+ crops", lastSync: "2 days ago", available: true },
  { icon: <Bug className="h-5 w-5 text-amber-600" />, title: "Disease Information", items: "180+ diseases", lastSync: "2 days ago", available: true },
  { icon: <Lightbulb className="h-5 w-5 text-yellow-500" />, title: "Farming Tips", items: "500+ tips", lastSync: "3 days ago", available: true },
  { icon: <Database className="h-5 w-5 text-sky" />, title: "Weather Patterns", items: "Local history", lastSync: "1 day ago", available: true },
  { icon: <RefreshCw className="h-5 w-5 text-slate-400" />, title: "AI Chat Responses", items: "Common questions", lastSync: "Need sync", available: false },
  { icon: <Database className="h-5 w-5 text-slate-400" />, title: "Market Prices", items: "Latest prices", lastSync: "Need sync", available: false },
]

const OFFLINE_TIPS = [
  "Check crop disease database with photos",
  "View farming calendar for your region",
  "Read irrigation guides for your soil type",
  "Access pest management guides",
  "View MSP (Minimum Support Prices) for major crops",
]

export function OfflineScreen() {
  const { setScreen, t, isOnline } = useApp()
  const [syncing, setSyncing] = useState(false)
  const [syncDone, setSyncDone] = useState(false)

  const handleSync = () => {
    if (!isOnline) return
    setSyncing(true)
    setTimeout(() => {
      setSyncing(false)
      setSyncDone(true)
    }, 3000)
  }

  const availableCount = OFFLINE_RESOURCES.filter((r) => r.available).length

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <PageHeader
        title={t("offlineTitle")}
        subtitle="Works without internet"
        onBack={() => setScreen("dashboard")}
      />

      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-5 pb-8">
        {/* Status banner */}
        <div className={`rounded-2xl p-5 ${isOnline ? "bg-primary" : "bg-amber-500"}`}>
          <div className="flex items-center gap-3 mb-3">
            <div className={`h-10 w-10 rounded-full flex items-center justify-center ${isOnline ? "bg-white/20" : "bg-white/20"}`}>
              <WifiOff className="h-5 w-5 text-white" />
            </div>
            <div>
              <p className="text-base font-bold text-white font-heading">
                {isOnline ? "Currently Online" : "Offline Mode Active"}
              </p>
              <p className="text-xs text-white/70">
                {isOnline ? "Full AI features available" : t("offlineDesc")}
              </p>
            </div>
          </div>
          <div className="rounded-xl bg-white/15 p-3">
            <p className="text-xs text-white/80 text-center">
              {availableCount} of {OFFLINE_RESOURCES.length} databases ready for offline use
            </p>
          </div>
        </div>

        {/* Offline database list */}
        <div className="rounded-2xl bg-card border border-border p-4">
          <h2 className="text-sm font-bold text-foreground mb-3">Offline Database</h2>
          <div className="space-y-3">
            {OFFLINE_RESOURCES.map((res) => (
              <div key={res.title} className="flex items-center gap-3">
                <div className={`h-10 w-10 rounded-xl flex items-center justify-center flex-shrink-0 ${res.available ? "bg-primary/10" : "bg-muted"}`}>
                  {res.icon}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-semibold text-foreground">{res.title}</p>
                  <p className="text-xs text-muted-foreground">{res.items} · Last sync: {res.lastSync}</p>
                </div>
                {res.available ? (
                  <CheckCircle2 className="h-5 w-5 text-primary flex-shrink-0" />
                ) : (
                  <Clock className="h-5 w-5 text-muted-foreground flex-shrink-0" />
                )}
              </div>
            ))}
          </div>
        </div>

        {/* What you can do offline */}
        <div className="rounded-2xl bg-card border border-border p-4">
          <h2 className="text-sm font-bold text-foreground mb-3">Available Offline</h2>
          <div className="space-y-2">
            {OFFLINE_TIPS.map((tip) => (
              <div key={tip} className="flex items-start gap-2.5">
                <CheckCircle2 className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
                <p className="text-sm text-muted-foreground">{tip}</p>
              </div>
            ))}
          </div>
        </div>

        {/* What needs internet */}
        <div className="rounded-2xl bg-muted p-4">
          <h2 className="text-sm font-bold text-muted-foreground mb-3">Requires Internet</h2>
          <div className="space-y-2">
            {["Real-time AI chat responses", "Live weather updates", "Latest market prices", "Image disease analysis"].map((item) => (
              <div key={item} className="flex items-center gap-2.5">
                <WifiOff className="h-4 w-4 text-muted-foreground flex-shrink-0" />
                <p className="text-sm text-muted-foreground">{item}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Sync button */}
        {syncDone ? (
          <div className="rounded-2xl bg-primary/10 border border-primary/20 p-4 flex items-center gap-3">
            <CheckCircle2 className="h-6 w-6 text-primary flex-shrink-0" />
            <div>
              <p className="text-sm font-semibold text-foreground">All databases updated!</p>
              <p className="text-xs text-muted-foreground">Your app is ready for offline use.</p>
            </div>
          </div>
        ) : (
          <button
            onClick={handleSync}
            disabled={syncing || !isOnline}
            className="w-full flex items-center justify-center gap-3 rounded-2xl bg-primary py-4 text-sm font-bold text-primary-foreground hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all font-heading"
          >
            {syncing ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Syncing databases...
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4" />
                {t("syncNow")}
              </>
            )}
          </button>
        )}

        {!isOnline && (
          <p className="text-center text-xs text-muted-foreground">Connect to internet to sync latest data</p>
        )}
      </div>
    </div>
  )
}
