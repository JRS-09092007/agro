"use client"

import { useState } from "react"
import { useApp, SOIL_TYPES, SEASONS, WATER_AVAILABILITY } from "@/lib/app-context"
import { CropRecommendationCard, PageHeader } from "@/components/krishi/shared"
import { ChevronDown, Loader2, Sprout } from "lucide-react"

interface SelectProps {
  label: string
  value: string
  options: string[]
  onChange: (v: string) => void
}

function Select({ label, value, options, onChange }: SelectProps) {
  return (
    <div>
      <label className="block text-xs font-semibold text-muted-foreground mb-1.5 uppercase tracking-wide">{label}</label>
      <div className="relative">
        <select
          value={value}
          onChange={(e) => onChange(e.target.value)}
          className="w-full appearance-none rounded-xl border border-input bg-card px-4 py-3.5 text-sm text-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 pr-10 transition-all"
        >
          <option value="">Select...</option>
          {options.map((o) => <option key={o} value={o}>{o}</option>)}
        </select>
        <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground pointer-events-none" />
      </div>
    </div>
  )
}

interface CropResult {
  crop: string
  reason: string
  waterReq: string
  season: string
  benefit: string
}

const CROP_DATA: Record<string, CropResult[]> = {
  "Black Soil": [
    { crop: "Soybean", reason: "Black soil retains moisture well, perfect for soybean root development. Medium rainfall in Maharashtra suits its needs.", waterReq: "600-900mm", season: "Kharif", benefit: "₹4000/qtl" },
    { crop: "Cotton", reason: "Black cotton soil (Regur) is the ideal natural habitat for cotton. Deep roots benefit from high water retention.", waterReq: "500-1000mm", season: "Kharif", benefit: "₹6500/qtl" },
  ],
  "Red Soil": [
    { crop: "Groundnut", reason: "Red soil's well-drained, loose texture is ideal for groundnut pod development underground.", waterReq: "500-700mm", season: "Kharif", benefit: "₹5500/qtl" },
    { crop: "Millets", reason: "Red soil with low water retention suits drought-tolerant millets that don't need excess moisture.", waterReq: "300-500mm", season: "Kharif", benefit: "₹2200/qtl" },
  ],
  "Alluvial Soil": [
    { crop: "Wheat", reason: "Alluvial soil's high fertility and moisture capacity makes it ideal for wheat cultivation in Rabi season.", waterReq: "450-650mm", season: "Rabi", benefit: "₹2150/qtl" },
    { crop: "Sugarcane", reason: "Deep alluvial soil supports sugarcane's extensive root system and high nutrient demand.", waterReq: "1500-2500mm", season: "Annual", benefit: "₹350/qtl" },
  ],
  "Sandy Soil": [
    { crop: "Watermelon", reason: "Sandy soil's excellent drainage and warming capacity promotes fruit development in watermelon.", waterReq: "400-600mm", season: "Zaid", benefit: "₹800/qtl" },
    { crop: "Peanuts", reason: "Sandy loam soil allows easy pod development and makes harvesting peanuts much easier.", waterReq: "450-550mm", season: "Kharif", benefit: "₹5000/qtl" },
  ],
  "Clay Soil": [
    { crop: "Rice", reason: "Clay soil retains water perfectly for paddy cultivation, maintaining the flooded conditions rice needs.", waterReq: "1200-2000mm", season: "Kharif", benefit: "₹2100/qtl" },
    { crop: "Jute", reason: "Heavy clay retains moisture required for jute fiber development over long growing periods.", waterReq: "1500-2000mm", season: "Kharif", benefit: "₹4200/qtl" },
  ],
  "Loamy Soil": [
    { crop: "Maize", reason: "Loamy soil's balanced texture provides perfect drainage while retaining enough nutrients for maize.", waterReq: "500-800mm", season: "Kharif", benefit: "₹1850/qtl" },
    { crop: "Tomato", reason: "Well-drained loamy soil with good organic matter supports healthy tomato root and fruit development.", waterReq: "600-1200mm", season: "Rabi", benefit: "₹1500/qtl" },
  ],
}

export function CropScreen() {
  const { setScreen, farmer, t } = useApp()
  const [soilType, setSoilType] = useState(farmer.soilType || "")
  const [season, setSeason] = useState("")
  const [waterAvail, setWaterAvail] = useState(farmer.waterAvailability || "")
  const [location, setLocation] = useState(farmer.district || "")
  const [results, setResults] = useState<CropResult[]>([])
  const [loading, setLoading] = useState(false)
  const [hasSearched, setHasSearched] = useState(false)

  const handleGetRecommendation = () => {
    if (!soilType) return
    setLoading(true)
    setHasSearched(true)
    setTimeout(() => {
      const data = CROP_DATA[soilType] || CROP_DATA["Loamy Soil"]
      setResults(data)
      setLoading(false)
    }, 1500)
  }

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <PageHeader
        title={t("cropTitle")}
        subtitle={t("cropSubtitle")}
        onBack={() => setScreen("dashboard")}
      />

      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-5 pb-8">
        {/* Input form */}
        <div className="rounded-2xl bg-card border border-border p-4 space-y-4">
          <h2 className="text-sm font-bold text-foreground">Farm Details</h2>
          <Select label={t("soilType")} value={soilType} options={SOIL_TYPES} onChange={setSoilType} />
          <Select label={t("season")} value={season} options={SEASONS} onChange={setSeason} />
          <Select label={t("waterAvailability")} value={waterAvail} options={WATER_AVAILABILITY} onChange={setWaterAvail} />
          <div>
            <label className="block text-xs font-semibold text-muted-foreground mb-1.5 uppercase tracking-wide">{t("location")}</label>
            <input
              type="text"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
              placeholder="District / Region"
              className="w-full rounded-xl border border-input bg-background px-4 py-3.5 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 transition-all"
            />
          </div>
          <button
            onClick={handleGetRecommendation}
            disabled={!soilType || loading}
            className="w-full rounded-2xl bg-primary py-4 text-sm font-bold text-primary-foreground hover:bg-primary/90 disabled:opacity-50 disabled:cursor-not-allowed transition-all flex items-center justify-center gap-2 font-heading"
          >
            {loading ? (
              <>
                <Loader2 className="h-4 w-4 animate-spin" />
                Analyzing with Gemini AI...
              </>
            ) : (
              <>
                <Sprout className="h-4 w-4" />
                {t("getRecommendation")}
              </>
            )}
          </button>
        </div>

        {/* Results */}
        {hasSearched && !loading && results.length > 0 && (
          <div className="space-y-4">
            <h2 className="text-sm font-bold text-foreground">AI Recommendations</h2>
            <div className="rounded-2xl bg-primary/5 border border-primary/10 p-3 flex items-start gap-2">
              <div className="h-5 w-5 rounded-full bg-primary flex items-center justify-center flex-shrink-0 mt-0.5">
                <Sprout className="h-3 w-3 text-white" />
              </div>
              <p className="text-xs text-muted-foreground leading-relaxed">
                Based on your <strong className="text-foreground">{soilType}</strong> in <strong className="text-foreground">{location || farmer.district}</strong>, here are the best crops for optimal yield this season.
              </p>
            </div>
            {results.map((r, i) => (
              <CropRecommendationCard key={i} {...r} />
            ))}
          </div>
        )}

        {/* Empty state */}
        {!hasSearched && (
          <div className="rounded-2xl border border-dashed border-border p-8 text-center">
            <Sprout className="h-10 w-10 text-muted-foreground mx-auto mb-3" />
            <p className="text-sm font-medium text-muted-foreground">Select your farm details above to get AI-powered crop recommendations</p>
          </div>
        )}
      </div>
    </div>
  )
}
