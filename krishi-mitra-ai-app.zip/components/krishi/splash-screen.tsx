"use client"

import { useApp, LANGUAGES } from "@/lib/app-context"
import { useState } from "react"
import { ChevronDown } from "lucide-react"

export function SplashScreen() {
  const { setScreen, setLanguage, language, t } = useApp()
  const [showLangPicker, setShowLangPicker] = useState(false)

  const currentLang = LANGUAGES.find((l) => l.code === language)

  return (
    <div className="flex min-h-screen flex-col bg-primary relative overflow-hidden">
      {/* Background pattern */}
      <div className="absolute inset-0 opacity-10">
        <svg viewBox="0 0 400 600" className="w-full h-full" preserveAspectRatio="xMidYMid slice">
          {/* Wheat/crop pattern */}
          {Array.from({ length: 12 }).map((_, i) => (
            <g key={i} transform={`translate(${(i % 4) * 100 + 20}, ${Math.floor(i / 4) * 200 + 50})`}>
              <line x1="0" y1="0" x2="0" y2="80" stroke="white" strokeWidth="2"/>
              <ellipse cx="-8" cy="20" rx="5" ry="12" fill="white" transform="rotate(-30)"/>
              <ellipse cx="8" cy="30" rx="5" ry="12" fill="white" transform="rotate(30)"/>
              <ellipse cx="-6" cy="45" rx="5" ry="12" fill="white" transform="rotate(-20)"/>
              <ellipse cx="6" cy="55" rx="5" ry="12" fill="white" transform="rotate(20)"/>
            </g>
          ))}
        </svg>
      </div>

      {/* Content */}
      <div className="relative z-10 flex flex-1 flex-col items-center justify-center px-6 py-12">
        {/* Logo */}
        <div className="mb-8 flex flex-col items-center">
          <div className="mb-4 flex h-24 w-24 items-center justify-center rounded-3xl bg-white/20 backdrop-blur-sm border border-white/30 shadow-xl">
            <svg viewBox="0 0 48 48" fill="none" className="h-14 w-14">
              {/* Leaf / plant icon */}
              <path d="M24 44V20" stroke="white" strokeWidth="2.5" strokeLinecap="round"/>
              <path
                d="M24 20C24 20 14 18 10 8C14 6 22 8 24 16C26 8 34 4 38 8C36 18 24 20 24 20Z"
                fill="white" fillOpacity="0.9"
              />
              <path d="M16 36C16 36 20 32 24 34" stroke="white" strokeWidth="2" strokeLinecap="round"/>
            </svg>
          </div>
          <h1 className="text-3xl font-extrabold text-white text-center font-heading tracking-tight">
            {t("appName")}
          </h1>
          <div className="mt-2 flex items-center gap-2">
            <div className="h-0.5 w-8 bg-white/40 rounded-full" />
            <p className="text-xs text-white/70 font-medium uppercase tracking-widest">AI Powered</p>
            <div className="h-0.5 w-8 bg-white/40 rounded-full" />
          </div>
        </div>

        {/* Tagline */}
        <div className="mb-10 max-w-xs text-center">
          <p className="text-base text-white/90 leading-relaxed font-medium">{t("tagline")}</p>
        </div>

        {/* Feature badges */}
        <div className="mb-10 flex flex-wrap justify-center gap-2">
          {["AI Powered", "6 Languages", "Offline Ready", "Voice Input"].map((f) => (
            <span key={f} className="rounded-full bg-white/15 px-3 py-1 text-xs text-white font-medium border border-white/20">
              {f}
            </span>
          ))}
        </div>

        {/* Buttons */}
        <div className="w-full max-w-sm space-y-3">
          <button
            onClick={() => setScreen("registration")}
            className="w-full rounded-2xl bg-white py-4 text-base font-bold text-primary shadow-lg hover:bg-white/95 active:scale-98 transition-all duration-150 font-heading"
          >
            {t("startFarming")}
          </button>

          {/* Language selector */}
          <div className="relative">
            <button
              onClick={() => setShowLangPicker(!showLangPicker)}
              className="w-full flex items-center justify-between rounded-2xl border border-white/30 bg-white/15 backdrop-blur-sm px-5 py-4 text-base font-medium text-white hover:bg-white/20 transition-all"
            >
              <span>{t("selectLanguage")}</span>
              <div className="flex items-center gap-2">
                <span className="text-sm font-semibold">{currentLang?.native}</span>
                <ChevronDown className={`h-4 w-4 transition-transform ${showLangPicker ? "rotate-180" : ""}`} />
              </div>
            </button>

            {showLangPicker && (
              <div className="absolute bottom-full mb-2 left-0 right-0 rounded-2xl bg-card border border-border shadow-xl overflow-hidden z-20">
                {LANGUAGES.map((lang) => (
                  <button
                    key={lang.code}
                    onClick={() => {
                      setLanguage(lang.code)
                      setShowLangPicker(false)
                    }}
                    className={`w-full flex items-center justify-between px-5 py-3.5 text-sm font-medium transition-colors hover:bg-muted ${
                      language === lang.code ? "bg-primary/10 text-primary" : "text-foreground"
                    }`}
                  >
                    <span>{lang.label}</span>
                    <span className="font-semibold">{lang.native}</span>
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Bottom powered by */}
      <div className="relative z-10 pb-8 text-center">
        <p className="text-xs text-white/50">{t("poweredBy")}</p>
        <p className="text-xs text-white/30 mt-1">Hack2Skill Google AI Hackathon 2024</p>
      </div>
    </div>
  )
}
