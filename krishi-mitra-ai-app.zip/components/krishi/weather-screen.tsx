"use client"

import { useApp } from "@/lib/app-context"
import { PageHeader, WeatherCard } from "@/components/krishi/shared"
import { AlertTriangle, CloudRain, Thermometer, Wind, Bell, CheckCircle } from "lucide-react"

interface Alert {
  id: string
  type: "rain" | "dry" | "temperature" | "wind"
  severity: "low" | "medium" | "high"
  title: string
  description: string
  time: string
  advice: string
  read: boolean
}

const ALERTS: Alert[] = [
  {
    id: "1",
    type: "rain",
    severity: "high",
    title: "Heavy Rain Alert",
    description: "Heavy rainfall expected in Ahmednagar district after 2 days. Expected: 80-100mm in 24 hours.",
    time: "2 hours ago",
    advice: "Harvest mature crops before rainfall. Ensure proper drainage in fields. Avoid spraying pesticides.",
    read: false,
  },
  {
    id: "2",
    type: "temperature",
    severity: "medium",
    title: "Heat Wave Warning",
    description: "Temperature may rise to 40-42°C on Friday. High heat stress risk for crops.",
    time: "5 hours ago",
    advice: "Irrigate fields in early morning. Apply mulching to reduce soil temperature. Avoid field work during 12-4 PM.",
    read: false,
  },
  {
    id: "3",
    type: "dry",
    severity: "low",
    title: "Dry Spell Advisory",
    description: "No significant rainfall expected for the next 10 days after this week.",
    time: "Yesterday",
    advice: "Conserve water. Check borewell levels. Consider drought-tolerant crops for upcoming season.",
    read: true,
  },
  {
    id: "4",
    type: "wind",
    severity: "medium",
    title: "Strong Wind Advisory",
    description: "Wind speeds of 40-50 km/h expected on Wednesday afternoon.",
    time: "Yesterday",
    advice: "Support tall crops and fruit trees. Avoid spraying. Secure farm equipment and structures.",
    read: true,
  },
]

const alertConfig = {
  rain: { icon: CloudRain, color: "text-sky", bg: "bg-sky/10", border: "border-sky/20" },
  dry: { icon: Thermometer, color: "text-amber-500", bg: "bg-amber-50", border: "border-amber-200" },
  temperature: { icon: Thermometer, color: "text-orange-500", bg: "bg-orange-50", border: "border-orange-200" },
  wind: { icon: Wind, color: "text-slate-500", bg: "bg-slate-50", border: "border-slate-200" },
}

const severityConfig = {
  low: { label: "Advisory", color: "text-primary bg-primary/10" },
  medium: { label: "Warning", color: "text-amber-600 bg-amber-50" },
  high: { label: "Alert", color: "text-destructive bg-destructive/10" },
}

function AlertCard({ alert }: { alert: Alert }) {
  const config = alertConfig[alert.type]
  const severity = severityConfig[alert.severity]
  const Icon = config.icon

  return (
    <div className={`rounded-2xl border ${config.border} ${config.bg} p-4 ${!alert.read ? "ring-1 ring-primary/20" : ""}`}>
      <div className="flex items-start justify-between mb-3">
        <div className="flex items-center gap-3">
          <div className={`h-9 w-9 rounded-full flex items-center justify-center ${config.bg} border ${config.border}`}>
            <Icon className={`h-4.5 w-4.5 ${config.color}`} />
          </div>
          <div>
            <div className="flex items-center gap-2">
              <p className="text-sm font-bold text-foreground font-heading">{alert.title}</p>
              {!alert.read && (
                <span className="h-2 w-2 rounded-full bg-destructive flex-shrink-0" />
              )}
            </div>
            <p className="text-xs text-muted-foreground">{alert.time}</p>
          </div>
        </div>
        <span className={`text-xs font-semibold rounded-full px-2 py-0.5 ${severity.color}`}>
          {severity.label}
        </span>
      </div>
      <p className="text-sm text-foreground mb-3 leading-relaxed">{alert.description}</p>
      <div className="rounded-xl bg-card/60 p-3">
        <p className="text-xs font-semibold text-foreground mb-1">Recommended Action:</p>
        <p className="text-xs text-muted-foreground leading-relaxed">{alert.advice}</p>
      </div>
    </div>
  )
}

export function WeatherScreen() {
  const { setScreen, farmer, t } = useApp()
  const unreadCount = ALERTS.filter((a) => !a.read).length

  return (
    <div className="flex min-h-screen flex-col bg-background">
      <PageHeader
        title={t("weatherTitle")}
        subtitle={`${farmer.district}, ${farmer.state}`}
        onBack={() => setScreen("dashboard")}
        rightElement={
          unreadCount > 0 ? (
            <div className="flex items-center gap-1.5 rounded-full bg-destructive/10 px-3 py-1.5">
              <Bell className="h-3.5 w-3.5 text-destructive" />
              <span className="text-xs font-bold text-destructive">{unreadCount} New</span>
            </div>
          ) : undefined
        }
      />

      <div className="flex-1 overflow-y-auto px-4 py-5 space-y-5 pb-8">
        {/* Current weather */}
        <WeatherCard
          temp="32°C"
          condition="Partly Cloudy"
          location={`${farmer.village}, ${farmer.state}`}
          humidity="68%"
          wind="12 km/h"
        />

        {/* Quick stats */}
        <div className="grid grid-cols-3 gap-3">
          {[
            { label: "UV Index", value: "7 High", icon: Thermometer, color: "text-orange-500" },
            { label: "Rain Today", value: "0mm", icon: CloudRain, color: "text-sky" },
            { label: "Wind", value: "12 km/h", icon: Wind, color: "text-slate-500" },
          ].map((stat) => (
            <div key={stat.label} className="rounded-xl bg-card border border-border p-3 text-center">
              <stat.icon className={`h-5 w-5 mx-auto mb-1.5 ${stat.color}`} />
              <p className="text-sm font-bold text-foreground font-heading">{stat.value}</p>
              <p className="text-xs text-muted-foreground">{stat.label}</p>
            </div>
          ))}
        </div>

        {/* Alerts */}
        <div>
          <div className="flex items-center justify-between mb-3">
            <h2 className="text-sm font-bold text-foreground">Active Alerts</h2>
            <div className="flex items-center gap-1">
              <CheckCircle className="h-3.5 w-3.5 text-primary" />
              <span className="text-xs text-muted-foreground">{ALERTS.length - unreadCount} read</span>
            </div>
          </div>
          <div className="space-y-3">
            {ALERTS.map((alert) => (
              <AlertCard key={alert.id} alert={alert} />
            ))}
          </div>
        </div>

        {/* Notification settings */}
        <div className="rounded-2xl bg-card border border-border p-4">
          <h2 className="text-sm font-bold text-foreground mb-3 flex items-center gap-2">
            <Bell className="h-4 w-4 text-primary" />
            Alert Preferences
          </h2>
          <div className="space-y-3">
            {[
              { label: "Rain alerts", enabled: true },
              { label: "Temperature warnings", enabled: true },
              { label: "Pest outbreak alerts", enabled: false },
              { label: "Market price alerts", enabled: true },
            ].map((pref) => (
              <div key={pref.label} className="flex items-center justify-between">
                <p className="text-sm text-foreground">{pref.label}</p>
                <div className={`h-6 w-11 rounded-full transition-colors flex items-center px-0.5 ${pref.enabled ? "bg-primary" : "bg-muted"}`}>
                  <div className={`h-5 w-5 rounded-full bg-white shadow-sm transition-transform ${pref.enabled ? "translate-x-5" : "translate-x-0"}`} />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  )
}
