"use client"

import { useState } from "react"
import { GoogleMap, LoadScript, Marker, InfoWindow } from "@react-google-maps/api"
import { MapPin, Zap, AlertCircle } from "lucide-react"

const containerStyle = {
  width: "100%",
  height: "300px",
  borderRadius: "16px",
}

const defaultCenter = { lat: 19.7515, lng: 75.7139 } // Maharashtra center

// Google Maps integration for farm location & expert finder
interface FarmMapProps {
  latitude?: number
  longitude?: number
  farmName?: string
  showExpertNearby?: boolean
}

export function FarmMap({ latitude = 19.7515, longitude = 75.7139, farmName = "Your Farm", showExpertNearby = false }: FarmMapProps) {
  const [selectedMarker, setSelectedMarker] = useState<null | string>(null)

  const center = { lat: latitude, lng: longitude }

  // Mock nearby experts
  const nearbyExperts = showExpertNearby ? [
    { id: "e1", name: "Dr. Suresh Kumar", lat: latitude + 0.02, lng: longitude + 0.02, distance: "2.5 km" },
    { id: "e2", name: "Mrs. Priya Deshmukh", lat: latitude - 0.01, lng: longitude + 0.03, distance: "4.2 km" },
  ] : []

  return (
    <div className="w-full space-y-2">
      <LoadScript googleMapsApiKey={process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY || "AIzaSyDemoKey"}>
        <GoogleMap mapContainerStyle={containerStyle} center={center} zoom={13}>
          {/* Farm marker */}
          <Marker
            position={center}
            title={farmName}
            onClick={() => setSelectedMarker("farm")}
            icon={{
              path: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z",
              fillColor: "#16a34a",
              fillOpacity: 1,
              strokeColor: "#fff",
              strokeWeight: 2,
              scale: 1.5,
            }}
          />

          {/* Expert markers */}
          {nearbyExperts.map((expert) => (
            <Marker
              key={expert.id}
              position={{ lat: expert.lat, lng: expert.lng }}
              title={expert.name}
              onClick={() => setSelectedMarker(expert.id)}
              icon={{
                path: "M12 2C6.48 2 2 6.48 2 12s4.48 10 10 10 10-4.48 10-10S17.52 2 12 2z",
                fillColor: "#2563eb",
                fillOpacity: 1,
                strokeColor: "#fff",
                strokeWeight: 2,
                scale: 1.2,
              }}
            />
          ))}

          {/* Info windows */}
          {selectedMarker === "farm" && (
            <InfoWindow
              position={center}
              onCloseClick={() => setSelectedMarker(null)}
            >
              <div className="bg-white p-2 rounded-lg">
                <p className="text-xs font-bold text-foreground">{farmName}</p>
                <p className="text-xs text-muted-foreground">{latitude.toFixed(4)}, {longitude.toFixed(4)}</p>
              </div>
            </InfoWindow>
          )}

          {nearbyExperts.map((expert) => (
            selectedMarker === expert.id && (
              <InfoWindow
                key={expert.id}
                position={{ lat: expert.lat, lng: expert.lng }}
                onCloseClick={() => setSelectedMarker(null)}
              >
                <div className="bg-white p-2 rounded-lg">
                  <p className="text-xs font-bold text-foreground">{expert.name}</p>
                  <p className="text-xs text-primary font-medium">{expert.distance} away</p>
                </div>
              </InfoWindow>
            )
          ))}
        </GoogleMap>
      </LoadScript>

      {showExpertNearby && nearbyExperts.length > 0 && (
        <div className="bg-primary/5 border border-primary/20 rounded-xl p-3">
          <div className="flex items-start gap-2">
            <MapPin className="h-4 w-4 text-primary flex-shrink-0 mt-0.5" />
            <div className="text-xs">
              <p className="font-semibold text-foreground mb-1">{nearbyExperts.length} Experts Nearby</p>
              {nearbyExperts.map((e) => (
                <p key={e.id} className="text-muted-foreground">{e.name} • {e.distance}</p>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  )
}

// Earth Engine data visualization component
// Shows crop health, soil moisture, and vegetation indices
interface EarthEngineDataProps {
  latitude?: number
  longitude?: number
  dataType: "ndvi" | "moisture" | "temperature"
}

export function EarthEngineVisualization({ latitude = 19.7515, longitude = 75.7139, dataType = "ndvi" }: EarthEngineDataProps) {
  const getDataInfo = () => {
    switch (dataType) {
      case "ndvi":
        return {
          title: "Vegetation Index (NDVI)",
          description: "Healthy crops have higher NDVI values. Values > 0.4 indicate good crop health.",
          value: "0.68",
          status: "Excellent",
          icon: <Zap className="h-5 w-5" />,
          color: "bg-green-100 text-green-700",
        }
      case "moisture":
        return {
          title: "Soil Moisture",
          description: "Current soil moisture level from Earth Engine analysis.",
          value: "42%",
          status: "Optimal",
          icon: <AlertCircle className="h-5 w-5" />,
          color: "bg-blue-100 text-blue-700",
        }
      case "temperature":
        return {
          title: "Temperature Index",
          description: "Land surface temperature from satellite data.",
          value: "28.5°C",
          status: "Normal",
          icon: <Zap className="h-5 w-5" />,
          color: "bg-amber-100 text-amber-700",
        }
      default:
        return {
          title: "Data",
          description: "",
          value: "---",
          status: "N/A",
          icon: null,
          color: "bg-gray-100 text-gray-700",
        }
    }
  }

  const data = getDataInfo()

  return (
    <div className="rounded-2xl bg-card border border-border p-4 space-y-3">
      <div className="flex items-start justify-between">
        <div>
          <h3 className="text-sm font-bold text-foreground">{data.title}</h3>
          <p className="text-xs text-muted-foreground mt-1">{data.description}</p>
        </div>
        <div className={`h-10 w-10 rounded-full flex items-center justify-center flex-shrink-0 ${data.color}`}>
          {data.icon}
        </div>
      </div>
      
      <div className="grid grid-cols-2 gap-3">
        <div className="rounded-lg bg-muted p-3">
          <p className="text-xs text-muted-foreground mb-1">Current Value</p>
          <p className="text-lg font-bold text-foreground">{data.value}</p>
        </div>
        <div className="rounded-lg bg-muted p-3">
          <p className="text-xs text-muted-foreground mb-1">Status</p>
          <p className="text-lg font-bold text-primary">{data.status}</p>
        </div>
      </div>

      <div className="rounded-lg bg-muted p-2.5 h-24 flex items-end justify-between gap-1">
        {[45, 62, 58, 72, 88, 65, 71].map((v, i) => (
          <div
            key={i}
            className="flex-1 rounded-sm bg-primary/40"
            style={{ height: `${(v / 100) * 100}%` }}
            title={`Day ${i + 1}: ${v}%`}
          />
        ))}
      </div>
      <p className="text-xs text-muted-foreground text-center">7-day trend</p>
    </div>
  )
}

// Satellite imagery tile for disease detection
export function SatelliteImagery({ latitude = 19.7515, longitude = 75.7139 }: { latitude?: number; longitude?: number }) {
  return (
    <div className="rounded-2xl bg-card border border-border overflow-hidden">
      <div
        className="w-full h-56 bg-gradient-to-br from-green-400 via-blue-400 to-green-500 relative overflow-hidden"
      >
        {/* Simulated satellite imagery with NDVI visualization */}
        <div className="absolute inset-0">
          <svg className="w-full h-full" viewBox="0 0 400 300" preserveAspectRatio="none">
            {/* Healthy crop area - green */}
            <polygon points="50,50 200,40 220,150 80,160" fill="#22c55e" opacity="0.8" />
            {/* Stressed area - yellow */}
            <polygon points="200,40 350,60 380,180 220,150" fill="#eab308" opacity="0.7" />
            {/* Water body - blue */}
            <ellipse cx="100" cy="220" rx="80" ry="50" fill="#3b82f6" opacity="0.6" />
            {/* Diseased area - red */}
            <polygon points="280,200 350,190 380,280 300,290" fill="#ef4444" opacity="0.6" />
          </svg>
        </div>

        {/* Legend overlay */}
        <div className="absolute bottom-3 left-3 bg-black/50 backdrop-blur-sm rounded-lg px-3 py-2">
          <div className="flex items-center gap-2 text-xs">
            <div className="flex items-center gap-1">
              <div className="h-2 w-2 rounded-full bg-green-400" />
              <span className="text-white">Healthy</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="h-2 w-2 rounded-full bg-yellow-400" />
              <span className="text-white">Stressed</span>
            </div>
            <div className="flex items-center gap-1">
              <div className="h-2 w-2 rounded-full bg-red-400" />
              <span className="text-white">Diseased</span>
            </div>
          </div>
        </div>
      </div>

      <div className="p-3 space-y-2">
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Satellite Date</span>
          <span className="font-semibold text-foreground">Jan 15, 2024</span>
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Resolution</span>
          <span className="font-semibold text-foreground">10m pixels</span>
        </div>
        <div className="flex items-center justify-between text-xs">
          <span className="text-muted-foreground">Source</span>
          <span className="font-semibold text-foreground">Sentinel-2 (ESA)</span>
        </div>
      </div>
    </div>
  )
}
